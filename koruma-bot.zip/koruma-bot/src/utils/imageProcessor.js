const axios = require('axios');
const sharp = require('sharp');
const fetch = require('node-fetch');
const { createApi } = require('unsplash-js');
const { Tenor } = require('tenorjs');
const logger = require('./logger');

// Unsplash API oluşturma (görsel aramak için)
// Not: Gerçek bir proje için bir API anahtarı almalısınız
const unsplash = createApi({
  accessKey: 'YOUR_UNSPLASH_ACCESS_KEY', // Bu anahtar örnek amaçlıdır
  fetch: fetch,
});

// Tenor API yapılandırması (GIF aramak için)
// Not: Gerçek bir proje için bir API anahtarı almalısınız
const tenor = new Tenor({
  Key: 'YOUR_TENOR_API_KEY', // Bu anahtar örnek amaçlıdır
  Filter: 'medium',
  Locale: 'tr_TR',
  MediaFilter: 'minimal',
  DateFormat: 'D/MM/YYYY - H:mm:ss A',
});

/**
 * Rastgele bir görsel URL'si alır
 * @returns {Promise<string>} Görsel URL'si
 */
async function getRandomImage() {
  try {
    // Unsplash API kullanarak rastgele görsel alma
    const result = await unsplash.photos.getRandom({
      count: 1,
    });
    
    if (result.errors) {
      // Hata durumunda yedek kaynak kullan
      logger.warn(`Unsplash API hatası: ${result.errors[0]}`);
      return getRandomImageFallback();
    }
    
    return result.response[0].urls.regular;
  } catch (error) {
    logger.error(`Rastgele görsel alma hatası: ${error}`);
    return getRandomImageFallback();
  }
}

/**
 * Yedek rastgele görsel kaynağı
 * @returns {Promise<string>} Görsel URL'si
 */
async function getRandomImageFallback() {
  try {
    // Picsum API ile rastgele görsel alma
    const randomId = Math.floor(Math.random() * 1000);
    return `https://picsum.photos/seed/${randomId}/512/512`;
  } catch (error) {
    logger.error(`Yedek görsel kaynağı hatası: ${error}`);
    throw error;
  }
}

/**
 * Rastgele bir GIF URL'si alır
 * @returns {Promise<string>} GIF URL'si
 */
async function getRandomGif() {
  try {
    // Tenor API kullanarak rastgele GIF alma
    const response = await tenor.Search.Random('random', 1);
    
    if (response && response.length > 0) {
      return response[0].media[0].gif.url;
    } else {
      // Hata durumunda yedek kaynak kullan
      return getRandomGifFallback();
    }
  } catch (error) {
    logger.error(`Rastgele GIF alma hatası: ${error}`);
    return getRandomGifFallback();
  }
}

/**
 * Yedek rastgele GIF kaynağı
 * @returns {Promise<string>} GIF URL'si
 */
async function getRandomGifFallback() {
  try {
    // Giphy API ile rastgele GIF alma (API key olmadan)
    const response = await axios.get('https://api.giphy.com/v1/gifs/random?api_key=6NhQvblwsEKgUwKJOaaYMweGnhixVg8w&rating=g');
    return response.data.data.images.fixed_height.url;
  } catch (error) {
    logger.error(`Yedek GIF kaynağı hatası: ${error}`);
    // Son çare olarak sabit bir GIF
    return 'https://media.tenor.com/images/36788d5f0ed6d31f96f3a4d2817b5f4f/tenor.gif';
  }
}

/**
 * Arama terimlerine göre görsel URL'si alır
 * @param {string} query - Arama terimi
 * @returns {Promise<string>} Görsel URL'si
 */
async function getImageByQuery(query) {
  try {
    // Unsplash API kullanarak görsel arama
    const result = await unsplash.search.getPhotos({
      query: query,
      page: 1,
      perPage: 10,
    });
    
    if (result.errors || result.response.results.length === 0) {
      // Hata durumunda yedek kaynak kullan
      logger.warn(`Unsplash API sorgu hatası: ${result.errors ? result.errors[0] : 'Sonuç bulunamadı'}`);
      return getImageByQueryFallback(query);
    }
    
    // Rastgele bir sonuç seç
    const randomIndex = Math.floor(Math.random() * Math.min(result.response.results.length, 10));
    return result.response.results[randomIndex].urls.regular;
  } catch (error) {
    logger.error(`Sorguya göre görsel alma hatası: ${error}`);
    return getImageByQueryFallback(query);
  }
}

/**
 * Yedek sorgu tabanlı görsel kaynağı
 * @param {string} query - Arama terimi
 * @returns {Promise<string>} Görsel URL'si
 */
async function getImageByQueryFallback(query) {
  try {
    // Pexels API ile görsel arama (API key olmadan, gizlenmiş bir endpoint)
    return `https://source.unsplash.com/featured/?${encodeURIComponent(query)}`;
  } catch (error) {
    logger.error(`Yedek sorgu görsel kaynağı hatası: ${error}`);
    return getRandomImageFallback();
  }
}

/**
 * Arama terimlerine göre GIF URL'si alır
 * @param {string} query - Arama terimi
 * @returns {Promise<string>} GIF URL'si
 */
async function getGifByQuery(query) {
  try {
    // Tenor API kullanarak GIF arama
    const response = await tenor.Search.Query(query, 10);
    
    if (response && response.length > 0) {
      // Rastgele bir sonuç seç
      const randomIndex = Math.floor(Math.random() * Math.min(response.length, 10));
      return response[randomIndex].media[0].gif.url;
    } else {
      // Hata durumunda yedek kaynak kullan
      return getGifByQueryFallback(query);
    }
  } catch (error) {
    logger.error(`Sorguya göre GIF alma hatası: ${error}`);
    return getGifByQueryFallback(query);
  }
}

/**
 * Yedek sorgu tabanlı GIF kaynağı
 * @param {string} query - Arama terimi
 * @returns {Promise<string>} GIF URL'si
 */
async function getGifByQueryFallback(query) {
  try {
    // Giphy API ile GIF arama (API key olmadan)
    const response = await axios.get(`https://api.giphy.com/v1/gifs/search?api_key=6NhQvblwsEKgUwKJOaaYMweGnhixVg8w&q=${encodeURIComponent(query)}&limit=10&rating=g`);
    
    if (response.data.data.length > 0) {
      // Rastgele bir sonuç seç
      const randomIndex = Math.floor(Math.random() * Math.min(response.data.data.length, 10));
      return response.data.data[randomIndex].images.fixed_height.url;
    } else {
      return getRandomGifFallback();
    }
  } catch (error) {
    logger.error(`Yedek sorgu GIF kaynağı hatası: ${error}`);
    return getRandomGifFallback();
  }
}

/**
 * Görüntüyü emoji boyutuna yeniden boyutlandırır
 * @param {Buffer} imageBuffer - Görüntü buffer'ı
 * @returns {Promise<Buffer>} Yeniden boyutlandırılmış görüntü buffer'ı
 */
async function resizeImageForEmoji(imageBuffer) {
  try {
    // Discord emoji boyutu: maksimum 128x128 piksel, 256KB
    return await sharp(imageBuffer)
      .resize(128, 128, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .toBuffer();
  } catch (error) {
    logger.error(`Görüntü yeniden boyutlandırma hatası: ${error}`);
    throw error;
  }
}

/**
 * URL'den görüntü buffer'ı alır
 * @param {string} url - Görüntü URL'si
 * @returns {Promise<Buffer>} Görüntü buffer'ı
 */
async function getImageBufferFromUrl(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data, 'binary');
  } catch (error) {
    logger.error(`URL'den görüntü alma hatası: ${error}`);
    throw error;
  }
}

module.exports = {
  getRandomImage,
  getRandomGif,
  getImageByQuery,
  getGifByQuery,
  resizeImageForEmoji,
  getImageBufferFromUrl
};
