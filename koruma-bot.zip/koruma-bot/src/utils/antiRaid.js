const logger = require('./logger');
const ServerSettings = require('../models/serverSettings');

// Sunucu başına son katılımları takip etmek için
const recentJoins = new Map();

/**
 * Anti-raid koruma sistemi
 * @param {Object} client - Discord client
 * @param {Object} member - Sunucuya katılan kullanıcı
 * @returns {Promise<boolean>} İşlem yapıldı mı?
 */
async function handleRaidProtection(client, member) {
  try {
    // Sunucu ayarlarını getir
    const settings = await ServerSettings.findOne({ guildId: member.guild.id });
    
    // Anti-raid aktif değilse işlem yapma
    if (!settings || !settings.antiRaidEnabled) {
      return false;
    }
    
    // Sunucu ID'si için veri yapısını oluştur eğer yoksa
    if (!recentJoins.has(member.guild.id)) {
      recentJoins.set(member.guild.id, []);
    }
    
    const guildJoins = recentJoins.get(member.guild.id);
    const now = Date.now();
    
    // Zaman penceresi dışındaki girişleri temizle
    const timeWindow = settings.joinTimeWindow * 1000; // milisaniyeye çevir
    const validJoins = guildJoins.filter(timestamp => now - timestamp < timeWindow);
    
    // Yeni girişi ekle
    validJoins.push(now);
    recentJoins.set(member.guild.id, validJoins);
    
    // Eşik değerini kontrol et
    if (validJoins.length >= settings.joinThreshold) {
      logger.warn(`Anti-Raid: ${member.guild.name} sunucusunda raid algılandı! ${settings.joinTimeWindow} saniye içinde ${validJoins.length} kullanıcı katıldı.`);
      
      // Sunucuyu koruma moduna al
      await enableRaidProtection(member.guild, settings);
      
      // Log kanalına bilgi gönder
      if (settings.logChannelId) {
        const logChannel = member.guild.channels.cache.get(settings.logChannelId);
        if (logChannel) {
          logChannel.send({
            embeds: [{
              title: '⚠️ Anti-Raid Koruması Aktifleştirildi',
              description: `${settings.joinTimeWindow} saniye içinde ${validJoins.length} kullanıcı katıldı!\n\nSunucu koruma moduna alındı. Tüm yeni katılımlar yöneticiler tarafından tekrar değerlendirilene kadar engellenecek.`,
              color: 0xFF0000,
              timestamp: new Date()
            }]
          });
        }
      }
      
      return true;
    }
    
    return false;
  } catch (error) {
    logger.error(`Anti-Raid koruma hatası: ${error}`);
    return false;
  }
}

/**
 * Raid koruması etkinleştirildiğinde sunucuyu koruma moduna alır
 * @param {Object} guild - Discord sunucusu
 * @param {Object} settings - Sunucu ayarları
 */
async function enableRaidProtection(guild, settings) {
  try {
    // Verification level'ı en yükseğe çıkar
    await guild.setVerificationLevel(4); // 4 = VERY_HIGH
    
    // Sunucuya yeni katılanlara atanacak bir karantina rolü varsa
    if (settings.quarantineRoleId) {
      const joinedLast10Min = (await guild.members.fetch())
        .filter(m => (Date.now() - m.joinedTimestamp) < 600000) // Son 10 dakika
        .filter(m => !m.user.bot && !m.permissions.has('Administrator'));
        
      // Yeni katılan kullanıcılara karantina rolü ver
      for (const [id, member] of joinedLast10Min) {
        try {
          await member.roles.set([settings.quarantineRoleId], 'Anti-Raid Koruması: Karantina');
        } catch (e) {
          logger.error(`Karantina rolü verme hatası (${member.user.tag}): ${e}`);
        }
      }
    }
    
    // Tüm davetleri devre dışı bırak
    const invites = await guild.invites.fetch();
    for (const [code, invite] of invites) {
      try {
        await invite.delete('Anti-Raid Koruması: Davetler Devre Dışı');
      } catch (e) {
        logger.error(`Davet silme hatası (${code}): ${e}`);
      }
    }

    // Sunucu sahibine DM ile bilgi ver
    try {
      const owner = await guild.fetchOwner();
      await owner.send({
        embeds: [{
          title: '⚠️ Anti-Raid Koruması Aktifleştirildi',
          description: `**${guild.name}** sunucunuzda şüpheli bir raid aktivitesi algılandı ve koruma mekanizmaları otomatik olarak etkinleştirildi.\n\n**Alınan önlemler:**\n- Doğrulama seviyesi en yükseğe çıkarıldı\n- Tüm davetler devre dışı bırakıldı\n${settings.quarantineRoleId ? '- Son 10 dakikada katılan kullanıcılar karantinaya alındı' : ''}\n\nSunucunuzu kontrol ediniz ve güvenli olduğuna kanaat getirdiğinizde \`!raidkorumaiptal\` komutunu kullanarak normal moda geri dönebilirsiniz.`,
          color: 0xFF0000,
          timestamp: new Date()
        }]
      });
    } catch (e) {
      logger.error(`Sunucu sahibine DM gönderme hatası: ${e}`);
    }
  } catch (error) {
    logger.error(`Koruma modu etkinleştirme hatası: ${error}`);
  }
}

/**
 * Raid korumasını devre dışı bırakır ve sunucuyu normal haline döndürür
 * @param {Object} guild - Discord sunucusu
 */
async function disableRaidProtection(guild) {
  try {
    // Verification level'ı önceki haline getir (MEDIUM)
    await guild.setVerificationLevel(2);
    
    return true;
  } catch (error) {
    logger.error(`Koruma modunu devre dışı bırakma hatası: ${error}`);
    return false;
  }
}

module.exports = {
  handleRaidProtection,
  disableRaidProtection
};
