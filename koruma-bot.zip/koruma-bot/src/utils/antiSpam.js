const { Collection } = require('discord.js');
const logger = require('./logger');
const ServerSettings = require('../models/serverSettings');

// Kullanıcı başına mesaj takibi için
const userMessages = new Map();

/**
 * Anti-spam koruma sistemi
 * @param {Object} client - Discord client
 * @param {Object} message - Kullanıcı mesajı
 * @returns {Promise<boolean>} İşlem yapıldı mı?
 */
async function handleSpamProtection(client, message) {
  try {
    // Bot mesajlarını ve komutları yoksay
    if (message.author.bot || message.content.startsWith(client.config.prefix)) return false;
    
    // DM mesajlarını yoksay
    if (!message.guild) return false;
    
    // Sunucu ayarlarını getir
    const settings = await ServerSettings.findOne({ guildId: message.guild.id });
    
    // Anti-spam aktif değilse işlem yapma
    if (!settings || !settings.antiSpamEnabled) {
      return false;
    }
    
    const userId = message.author.id;
    const guildId = message.guild.id;
    const now = Date.now();
    const key = `${guildId}-${userId}`;
    
    // Kullanıcı için Map oluştur veya mevcut olanı al
    if (!userMessages.has(key)) {
      userMessages.set(key, new Collection());
    }
    
    const userMap = userMessages.get(key);
    const spamThreshold = settings.spamThreshold || 5;
    const spamTimeWindow = (settings.spamTimeWindow || 5) * 1000; // milisaniyeye çevir
    
    // Zaman penceresi dışındaki mesajları temizle
    const validMessages = Array.from(userMap.values()).filter(timestamp => now - timestamp < spamTimeWindow);
    userMap.clear();
    
    // Geçerli mesajların zaman bilgisini geri yükle
    validMessages.forEach(timestamp => {
      userMap.set(userMap.size, timestamp);
    });
    
    // Yeni mesajı ekle
    userMap.set(userMap.size, now);
    
    // Eşik değerini kontrol et
    if (userMap.size >= spamThreshold) {
      logger.warn(`Anti-Spam: ${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda spam algılandı! ${spamTimeWindow/1000} saniye içinde ${userMap.size} mesaj gönderdi.`);
      
      // Kullanıcıyı cezalandır
      await applySpamPunishment(message, settings);
      
      // Map'i temizle
      userMap.clear();
      return true;
    }
    
    return false;
  } catch (error) {
    logger.error(`Anti-Spam koruma hatası: ${error}`);
    return false;
  }
}

/**
 * Spam yapan kullanıcıya ceza uygular
 * @param {Object} message - Kullanıcı mesajı
 * @param {Object} settings - Sunucu ayarları
 */
async function applySpamPunishment(message, settings) {
  try {
    const { guild, channel, author, member } = message;
    
    // Son mesajları sil
    try {
      // Son 1 dakikada gönderilen mesajları getir ve filtrele
      const messages = await channel.messages.fetch({ limit: 50 });
      const userMessages = messages.filter(m => 
        m.author.id === author.id && 
        Date.now() - m.createdTimestamp < 60000
      );
      
      if (userMessages.size > 0) {
        await channel.bulkDelete(userMessages, true)
          .catch(e => logger.error(`Mesaj silme hatası: ${e}`));
        
        logger.info(`${author.tag} kullanıcısının ${userMessages.size} spam mesajı silindi.`);
      }
    } catch (error) {
      logger.error(`Spam mesajları silme hatası: ${error}`);
    }
    
    // Ceza türüne göre işlem yap
    if (settings.spamPunishmentType === 'mute') {
      // Timeout uygula (5 dakika)
      await member.timeout(5 * 60 * 1000, 'Anti-Spam Koruması: Spam yapma')
        .catch(e => logger.error(`Timeout hatası: ${e}`));
      
      logger.info(`${author.tag} kullanıcısı spam yaptığı için 5 dakika susturuldu.`);
    } else if (settings.spamPunishmentType === 'kick') {
      await member.kick('Anti-Spam Koruması: Spam yapma')
        .catch(e => logger.error(`Kick hatası: ${e}`));
      
      logger.info(`${author.tag} kullanıcısı spam yaptığı için sunucudan atıldı.`);
    } else if (settings.spamPunishmentType === 'ban') {
      await guild.members.ban(author.id, { reason: 'Anti-Spam Koruması: Spam yapma' })
        .catch(e => logger.error(`Ban hatası: ${e}`));
      
      logger.info(`${author.tag} kullanıcısı spam yaptığı için sunucudan yasaklandı.`);
    }
    
    // Log kanalına bilgi gönder
    if (settings.logChannelId) {
      const logChannel = guild.channels.cache.get(settings.logChannelId);
      if (logChannel) {
        const punishmentTypeText = {
          'mute': 'susturuldu (5 dakika)',
          'kick': 'sunucudan atıldı',
          'ban': 'sunucudan yasaklandı',
          'none': 'uyarıldı (ceza uygulanmadı)'
        };
        
        logChannel.send({
          embeds: [{
            title: '🚫 Anti-Spam Sistemi',
            description: `**${author.tag}** (${author.id}) kullanıcısı spam yaptığı tespit edildi ve ${punishmentTypeText[settings.spamPunishmentType || 'none']}.\n\nSpam mesajları temizlendi.`,
            color: 0xFF0000,
            timestamp: new Date()
          }]
        });
      }
    }
  } catch (error) {
    logger.error(`Spam cezası uygulama hatası: ${error}`);
  }
}

// Her 10 dakikada bir eski verileri temizle
setInterval(() => {
  const now = Date.now();
  
  userMessages.forEach((userMap, key) => {
    // 10 dakikadan eski tüm girdileri temizle
    const validMessages = Array.from(userMap.values()).filter(timestamp => now - timestamp < 600000);
    
    if (validMessages.length === 0) {
      // Hiç geçerli mesaj yoksa Map'i tamamen kaldır
      userMessages.delete(key);
    } else {
      // Geçerli mesajların zaman bilgisini güncelle
      userMap.clear();
      validMessages.forEach(timestamp => {
        userMap.set(userMap.size, timestamp);
      });
    }
  });
}, 600000); // 10 dakika

module.exports = {
  handleSpamProtection
};
