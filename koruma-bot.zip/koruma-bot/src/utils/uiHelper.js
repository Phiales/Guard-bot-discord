const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

/**
 * Standart bir başarı mesajı için embed oluşturur
 * @param {Object} options - Embed seçenekleri
 * @param {string} options.title - Embed başlığı
 * @param {string} options.description - Embed açıklaması
 * @param {Array} options.fields - Embed alanları
 * @param {Object} options.user - Kullanıcı bilgisi
 * @returns {EmbedBuilder} Oluşturulan embed
 */
function createSuccessEmbed({ title, description, fields = [], user }) {
  const embed = new EmbedBuilder()
    .setColor('#00FF00')
    .setTitle(`✅ ${title}`)
    .setDescription(description)
    .setTimestamp();
  
  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }
  
  if (user) {
    embed.setFooter({ text: `${user.tag} tarafından`, iconURL: user.displayAvatarURL() });
  }
  
  return embed;
}

/**
 * Standart bir hata mesajı için embed oluşturur
 * @param {Object} options - Embed seçenekleri
 * @param {string} options.title - Embed başlığı
 * @param {string} options.description - Embed açıklaması
 * @param {Array} options.fields - Embed alanları
 * @param {Object} options.user - Kullanıcı bilgisi
 * @returns {EmbedBuilder} Oluşturulan embed
 */
function createErrorEmbed({ title, description, fields = [], user }) {
  const embed = new EmbedBuilder()
    .setColor('#FF0000')
    .setTitle(`❌ ${title}`)
    .setDescription(description)
    .setTimestamp();
  
  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }
  
  if (user) {
    embed.setFooter({ text: `${user.tag} tarafından`, iconURL: user.displayAvatarURL() });
  }
  
  return embed;
}

/**
 * Standart bir bilgi mesajı için embed oluşturur
 * @param {Object} options - Embed seçenekleri
 * @param {string} options.title - Embed başlığı
 * @param {string} options.description - Embed açıklaması
 * @param {Array} options.fields - Embed alanları
 * @param {Object} options.user - Kullanıcı bilgisi
 * @returns {EmbedBuilder} Oluşturulan embed
 */
function createInfoEmbed({ title, description, fields = [], user }) {
  const embed = new EmbedBuilder()
    .setColor('#0099ff')
    .setTitle(`ℹ️ ${title}`)
    .setDescription(description)
    .setTimestamp();
  
  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }
  
  if (user) {
    embed.setFooter({ text: `${user.tag} tarafından`, iconURL: user.displayAvatarURL() });
  }
  
  return embed;
}

/**
 * Standart bir bekleme mesajı için embed oluşturur
 * @param {Object} options - Embed seçenekleri
 * @param {string} options.title - Embed başlığı
 * @param {string} options.description - Embed açıklaması
 * @param {Array} options.fields - Embed alanları
 * @param {Object} options.user - Kullanıcı bilgisi
 * @returns {EmbedBuilder} Oluşturulan embed
 */
function createLoadingEmbed({ title, description, fields = [], user }) {
  const embed = new EmbedBuilder()
    .setColor('#FFA500')
    .setTitle(`⏳ ${title}`)
    .setDescription(description)
    .setTimestamp();
  
  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }
  
  if (user) {
    embed.setFooter({ text: `${user.tag} tarafından`, iconURL: user.displayAvatarURL() });
  }
  
  return embed;
}

/**
 * Standart bir uyarı mesajı için embed oluşturur
 * @param {Object} options - Embed seçenekleri
 * @param {string} options.title - Embed başlığı
 * @param {string} options.description - Embed açıklaması
 * @param {Array} options.fields - Embed alanları
 * @param {Object} options.user - Kullanıcı bilgisi
 * @returns {EmbedBuilder} Oluşturulan embed
 */
function createWarningEmbed({ title, description, fields = [], user }) {
  const embed = new EmbedBuilder()
    .setColor('#FFFF00')
    .setTitle(`⚠️ ${title}`)
    .setDescription(description)
    .setTimestamp();
  
  if (fields && fields.length > 0) {
    embed.addFields(fields);
  }
  
  if (user) {
    embed.setFooter({ text: `${user.tag} tarafından`, iconURL: user.displayAvatarURL() });
  }
  
  return embed;
}

/**
 * Onay/İptal butonları içeren bir eylem satırı oluşturur
 * @returns {ActionRowBuilder} Oluşturulan eylem satırı
 */
function createConfirmCancelRow() {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('confirm')
        .setLabel('Onayla')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅'),
      new ButtonBuilder()
        .setCustomId('cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('❌')
    );
}

/**
 * Evet/Hayır butonları içeren bir eylem satırı oluşturur
 * @returns {ActionRowBuilder} Oluşturulan eylem satırı
 */
function createYesNoRow() {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('yes')
        .setLabel('Evet')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅'),
      new ButtonBuilder()
        .setCustomId('no')
        .setLabel('Hayır')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('❌')
    );
}

/**
 * Geri/İleri butonları içeren bir eylem satırı oluşturur
 * @returns {ActionRowBuilder} Oluşturulan eylem satırı
 */
function createNavigationRow() {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('prev')
        .setLabel('Önceki')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('◀️'),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('Sonraki')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('▶️')
    );
}

/**
 * Zaman aşımı mesajını gösterir
 * @param {Object} message - Discord mesaj nesnesi
 * @param {Object} user - Zaman aşımına uğrayan kullanıcı
 */
async function showTimeoutMessage(message, user) {
  const embed = createErrorEmbed({
    title: 'Zaman Aşımı',
    description: 'İşlem zaman aşımına uğradı. Lütfen komutu tekrar çalıştırın.',
    user
  });
  
  await message.edit({
    embeds: [embed],
    components: []
  });
}

module.exports = {
  createSuccessEmbed,
  createErrorEmbed,
  createInfoEmbed,
  createLoadingEmbed,
  createWarningEmbed,
  createConfirmCancelRow,
  createYesNoRow,
  createNavigationRow,
  showTimeoutMessage
};
