const ServerSettings = require('../models/serverSettings');
const logger = require('./logger');

/**
 * Kullanıcının belirtilen işlem için yetkisi olup olmadığını kontrol eder
 * @param {string} userId - Kontrol edilecek kullanıcı ID'si
 * @param {string} guildId - Sunucu ID'si
 * @param {string} actionType - İşlem türü (channelDelete, roleUpdate, memberBan vb.)
 * @returns {Promise<boolean>} Kullanıcı yetkili ise true, değilse false
 */
async function checkPermission(userId, guildId, actionType) {
  try {
    // Sunucu ayarlarını getir
    const settings = await ServerSettings.findOne({ guildId });
    if (!settings) return false;

    // Whitelist kontrolü
    if (settings.whitelistedUsers.includes(userId)) {
      return true;
    }

    // Sunucu varsa
    const guild = await global.client.guilds.fetch(guildId);
    if (!guild) return false;

    // Kullanıcıyı al
    let member;
    try {
      member = await guild.members.fetch(userId);
    } catch (error) {
      // Kullanıcı sunucuda değilse false döndür
      return false;
    }

    // Sunucu sahibi ise her zaman yetkili
    if (guild.ownerId === userId) {
      return true;
    }

    // Whitelisted rol kontrolü
    for (const roleId of settings.whitelistedRoles) {
      if (member.roles.cache.has(roleId)) {
        return true;
      }
    }

    // Belirli yetkilere sahip kullanıcılar için izin ver
    const isAdmin = member.permissions.has('Administrator');
    
    // Duruma göre özel kontroller
    if (actionType === 'channelDelete' || actionType === 'channelCreate' || actionType === 'channelUpdate') {
      if (member.permissions.has('ManageChannels') && isAdmin) {
        return true;
      }
    }
    
    if (actionType === 'roleDelete' || actionType === 'roleCreate' || actionType === 'roleUpdate') {
      if (member.permissions.has('ManageRoles') && isAdmin) {
        return true;
      }
    }
    
    if (actionType === 'memberBan') {
      if (member.permissions.has('BanMembers') && isAdmin) {
        return true;
      }
    }
    
    if (actionType === 'memberKick') {
      if (member.permissions.has('KickMembers') && isAdmin) {
        return true;
      }
    }
    
    if (actionType === 'webhookCreate' || actionType === 'webhookDelete' || actionType === 'webhookUpdate') {
      if (member.permissions.has('ManageWebhooks') && isAdmin) {
        return true;
      }
    }
    
    if (actionType === 'botAdd') {
      if (member.permissions.has('ManageGuild') && isAdmin) {
        return true;
      }
    }

    return false;
  } catch (error) {
    logger.error(`Yetki kontrolünde hata: ${error}`);
    return false;
  }
}

module.exports = {
  checkPermission
};
