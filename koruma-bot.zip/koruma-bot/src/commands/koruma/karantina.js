const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'karantina',
  aliases: ['quarantine', 'izolasyon'],
  description: 'Raid durumunda kullanıcılara verilecek karantina rolünü ayarlar',
  usage: 'karantina <rol/oluştur>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['rol', 'role', 'oluştur', 'olustur', 'create'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `karantina rol @rol` veya `karantina oluştur` yazmalısın.');
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Alt komuta göre işlem yap
      if (['rol', 'role'].includes(subCommand)) {
        // Rol etiketi kontrolü
        if (!message.mentions.roles.first()) {
          return message.reply('❌ Geçerli bir rol etiketlemelisin!');
        }
        
        const role = message.mentions.roles.first();
        
        // @everyone rolü kontrolü
        if (role.id === message.guild.id) {
          return message.reply('❌ @everyone rolünü karantina rolü olarak ayarlayamazsın!');
        }
        
        settings.quarantineRoleId = role.id;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Karantina Rolü Ayarlandı')
          .setDescription(`Raid durumunda verilecek karantina rolü başarıyla ${role} olarak ayarlandı.`)
          .addFields(
            { name: '📝 Bilgi', value: 'Raid algılandığında yeni katılan kullanıcılara bu rol otomatik olarak verilecek ve diğer rollerinden arındırılacaktır.' }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda karantina rolünü ${role.name} olarak ayarladı.`);
      }
      else if (['oluştur', 'olustur', 'create'].includes(subCommand)) {
        // Yeni bir karantina rolü oluştur
        try {
          const quarantineRole = await message.guild.roles.create({
            name: "Karantina",
            color: "#FF0000",
            permissions: new PermissionsBitField([]), // Hiçbir yetki verme
            reason: "Koruma Botu - Karantina rolü oluşturuldu",
            mentionable: false
          });
          
          // Tüm kanallarda izinleri düzenle
          await message.channel.send('⏳ Karantina rolü oluşturuldu. Tüm kanallarda izinler yapılandırılıyor...');
          
          // Sunucudaki tüm kanallar için izinleri düzenle
          const channels = [...message.guild.channels.cache.values()];
          let processedCount = 0;
          
          for (const channel of channels) {
            try {
              await channel.permissionOverwrites.create(quarantineRole, {
                ViewChannel: false,
                SendMessages: false,
                AddReactions: false,
                Connect: false,
                Speak: false
              });
              processedCount++;
            } catch (error) {
              logger.error(`Kanal izni ayarlama hatası (${channel.name}): ${error}`);
            }
          }
          
          // Ayarlara kaydet
          settings.quarantineRoleId = quarantineRole.id;
          await settings.save();
          
          const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Karantina Rolü Oluşturuldu')
            .setDescription(`Karantina rolü başarıyla oluşturuldu ve ${processedCount} kanalda izinler düzenlendi.`)
            .addFields(
              { name: '🔰 Rol', value: `${quarantineRole}` },
              { name: '📝 Bilgi', value: 'Raid algılandığında yeni katılan kullanıcılara bu rol otomatik olarak verilecek ve diğer rollerinden arındırılacaktır.' }
            )
            .setTimestamp()
            .setFooter({ text: `${message.author.tag} tarafından oluşturuldu`, iconURL: message.author.displayAvatarURL() });
          
          message.reply({ embeds: [embed] });
          logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda yeni bir karantina rolü oluşturdu.`);
        } catch (error) {
          logger.error(`Karantina rolü oluşturma hatası: ${error}`);
          message.reply('❌ Karantina rolü oluşturulurken bir hata oluştu! Yetki kontrolü yapın ve tekrar deneyin.');
        }
      }
    } catch (error) {
      logger.error(`Karantina komutu hatası: ${error}`);
      message.reply('❌ İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
