const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'guvenli',
  aliases: ['whitelist', 'güvenli'],
  description: 'Koruma sisteminde güvenli kullanıcı ve rolleri yönetir',
  usage: 'guvenli <ekle/çıkar/liste> <kullanıcı/rol>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    if (args.length < 1) {
      return message.reply('❌ Eksik parametre! Örnek kullanım: `guvenli ekle @kullanıcı` veya `guvenli çıkar @rol`');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['ekle', 'çıkar', 'cikar', 'liste', 'list', 'add', 'remove'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `ekle`, `çıkar` veya `liste` yazmalısın.');
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
        await settings.save();
      }
      
      // Alt komutlara göre işlem yap
      if (['liste', 'list'].includes(subCommand)) {
        // Güvenli listeyi görüntüle
        const embed = new EmbedBuilder()
          .setColor('#0099ff')
          .setTitle('🛡️ Güvenli Liste')
          .setDescription('Koruma sisteminden etkilenmeyecek kullanıcı ve roller:')
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
        
        // Güvenli kullanıcılar
        let usersField = '';
        if (settings.whitelistedUsers.length > 0) {
          for (const userId of settings.whitelistedUsers) {
            usersField += `<@${userId}>\n`;
          }
        } else {
          usersField = 'Güvenli kullanıcı bulunmuyor.';
        }
        
        // Güvenli roller
        let rolesField = '';
        if (settings.whitelistedRoles.length > 0) {
          for (const roleId of settings.whitelistedRoles) {
            rolesField += `<@&${roleId}>\n`;
          }
        } else {
          rolesField = 'Güvenli rol bulunmuyor.';
        }
        
        embed.addFields(
          { name: '👤 Güvenli Kullanıcılar', value: usersField },
          { name: '🔰 Güvenli Roller', value: rolesField }
        );
        
        return message.reply({ embeds: [embed] });
      } 
      
      // Ekle veya çıkar işlemleri için hedef gerekli
      if (args.length < 2) {
        return message.reply('❌ Hedef belirtmelisin! Örnek: `guvenli ekle @kullanıcı` veya `guvenli çıkar @rol`');
      }
      
      // Hedefi belirleme (kullanıcı veya rol)
      const target = message.mentions.members.first() || message.mentions.roles.first();
      
      if (!target) {
        return message.reply('❌ Geçerli bir kullanıcı veya rol etiketlemelisin!');
      }
      
      const isUser = target.user !== undefined;
      const targetId = isUser ? target.id : target.id;
      const targetType = isUser ? 'Kullanıcı' : 'Rol';
      const targetList = isUser ? 'whitelistedUsers' : 'whitelistedRoles';
      const targetName = isUser ? `${target.user.username}` : `${target.name}`;
      
      // Ekleme işlemi
      if (['ekle', 'add'].includes(subCommand)) {
        // Zaten ekli mi kontrol et
        if (settings[targetList].includes(targetId)) {
          return message.reply(`❌ Bu ${targetType.toLowerCase()} zaten güvenli listede!`);
        }
        
        // Listeye ekle
        settings[targetList].push(targetId);
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle(`✅ ${targetType} Güvenli Listeye Eklendi`)
          .setDescription(`**${targetName}** artık koruma sisteminden etkilenmeyecek.`)
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından eklendi`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${targetName} ${targetType.toLowerCase()}sini güvenli listeye ekledi.`);
      } 
      // Çıkarma işlemi
      else if (['çıkar', 'cikar', 'remove'].includes(subCommand)) {
        // Listede var mı kontrol et
        if (!settings[targetList].includes(targetId)) {
          return message.reply(`❌ Bu ${targetType.toLowerCase()} zaten güvenli listede değil!`);
        }
        
        // Listeden çıkar
        settings[targetList] = settings[targetList].filter(id => id !== targetId);
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle(`❌ ${targetType} Güvenli Listeden Çıkarıldı`)
          .setDescription(`**${targetName}** artık koruma sisteminden etkilenecek.`)
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından çıkarıldı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${targetName} ${targetType.toLowerCase()}sini güvenli listeden çıkardı.`);
      }
    } catch (error) {
      logger.error(`Güvenli komut hatası: ${error}`);
      message.reply('❌ İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
