const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'koruma',
  aliases: ['guard', 'protection'],
  description: 'Sunucu koruma sistemini açar veya kapatır',
  usage: 'koruma <aç/kapat>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['aç', 'kapat', 'ac', 'on', 'off'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `koruma aç` veya `koruma kapat` yazmalısın.');
    }
    
    const enable = ['aç', 'ac', 'on'].includes(subCommand);
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({
          guildId: message.guild.id,
          protectionEnabled: enable
        });
      } else {
        settings.protectionEnabled = enable;
      }
      
      await settings.save();
      
      const embed = new EmbedBuilder()
        .setColor(enable ? '#00FF00' : '#FF0000')
        .setTitle(`🛡️ Koruma Sistemi ${enable ? 'Aktifleştirildi' : 'Devre Dışı Bırakıldı'}`)
        .setDescription(`Sunucu koruma sistemi başarıyla ${enable ? '**aktifleştirildi**! Sunucunuz artık koruma altındadır.' : '**devre dışı bırakıldı**! Sunucunuz artık korunmuyor.'}`)
        .addFields(
          { name: '🔧 Yapılandırma', value: `Koruma ayarlarını düzenlemek için \`${client.config.prefix}korumaayarlar\` komutunu kullanabilirsiniz.` },
          { name: '📋 Durum', value: `Koruma: ${enable ? '✅ Aktif' : '❌ Devre Dışı'}` }
        )
        .setTimestamp()
        .setFooter({ text: `${message.author.tag} tarafından ${enable ? 'aktifleştirildi' : 'devre dışı bırakıldı'}`, iconURL: message.author.displayAvatarURL() });
      
      message.reply({ embeds: [embed] });
      
      logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda koruma sistemini ${enable ? 'aktifleştirdi' : 'devre dışı bıraktı'}.`);
    } catch (error) {
      logger.error(`Koruma komutu hatası: ${error}`);
      message.reply('❌ Ayarlar güncellenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
