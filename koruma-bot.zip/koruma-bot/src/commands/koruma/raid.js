const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed, createWarningEmbed, createConfirmCancelRow, createYesNoRow, showTimeoutMessage } = require('../../utils/uiHelper');
const ServerSettings = require('../../models/serverSettings');
const { disableRaidProtection } = require('../../utils/antiRaid');
const logger = require('../../utils/logger');

module.exports = {
  name: 'raid',
  aliases: ['antiraid', 'raidkoruma'],
  description: 'Raid koruma sistemini yapılandırır',
  usage: 'raid <aç/kapat/ayarla/iptal>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    // Komut parametresi kontrol et
    if (!args.length) {
      // Parametre yoksa interaktif menüyü göster
      return showInteractiveMenu(client, message);
    }
    
    const subCommand = args[0].toLowerCase();
    
    if (!['aç', 'kapat', 'ac', 'on', 'off', 'ayarla', 'iptal', 'setup', 'cancel'].includes(subCommand)) {
      const errorEmbed = createErrorEmbed({
        title: 'Geçersiz Parametre',
        description: '`raid aç`, `raid kapat`, `raid ayarla` veya `raid iptal` yazmalısın.',
        user: message.author
      });
      return message.reply({ embeds: [errorEmbed] });
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Alt komuta göre işlem yap
      if (['aç', 'ac', 'on'].includes(subCommand)) {
        settings.antiRaidEnabled = true;
        await settings.save();
        
        const embed = createSuccessEmbed({
          title: 'Raid Koruma Aktifleştirildi',
          description: 'Raid koruma sistemi başarıyla aktifleştirildi. Olası raid durumlarına karşı sunucunuz artık korunuyor.',
          fields: [
            { name: '⚠️ Tetikleyici', value: `${settings.joinThreshold} kullanıcı / ${settings.joinTimeWindow} saniye` },
            { name: '⚙️ Ayarlar', value: `Ayarları değiştirmek için \`${client.config.prefix}raid ayarla\` komutunu kullanabilirsiniz.` }
          ],
          user: message.author
        });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda raid koruma sistemini aktifleştirdi.`);
      } 
      else if (['kapat', 'off'].includes(subCommand)) {
        settings.antiRaidEnabled = false;
        await settings.save();
        
        const embed = createErrorEmbed({
          title: 'Raid Koruma Devre Dışı Bırakıldı',
          description: 'Raid koruma sistemi başarıyla devre dışı bırakıldı. Artık raid durumlarına karşı otomatik koruma sağlanmayacak.',
          user: message.author
        });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda raid koruma sistemini devre dışı bıraktı.`);
      }
      else if (['ayarla', 'setup'].includes(subCommand)) {
        // Threshold ve zaman penceresi ayarları için ek parametreler olmalı
        if (args.length < 3) {
          const errorEmbed = createErrorEmbed({
            title: 'Eksik Parametre',
            description: `Örnek kullanım: \`${client.config.prefix}raid ayarla 10 5\` (10 kullanıcı / 5 saniye)`,
            user: message.author
          });
          return message.reply({ embeds: [errorEmbed] });
        }
        
        const threshold = parseInt(args[1]);
        const timeWindow = parseInt(args[2]);
        
        if (isNaN(threshold) || threshold < 3 || threshold > 50) {
          const errorEmbed = createErrorEmbed({
            title: 'Geçersiz Değer',
            description: 'Kullanıcı sayısı 3 ile 50 arasında olmalıdır!',
            user: message.author
          });
          return message.reply({ embeds: [errorEmbed] });
        }
        
        if (isNaN(timeWindow) || timeWindow < 2 || timeWindow > 60) {
          const errorEmbed = createErrorEmbed({
            title: 'Geçersiz Değer',
            description: 'Zaman penceresi 2 ile 60 saniye arasında olmalıdır!',
            user: message.author
          });
          return message.reply({ embeds: [errorEmbed] });
        }
        
        settings.joinThreshold = threshold;
        settings.joinTimeWindow = timeWindow;
        await settings.save();
        
        const embed = createInfoEmbed({
          title: 'Raid Koruma Ayarları Güncellendi',
          description: `Raid koruma sistemi başarıyla yapılandırıldı. **${threshold}** kullanıcı **${timeWindow}** saniye içinde katılırsa koruma aktifleşecek.`,
          fields: [
            { name: '🔄 Durum', value: settings.antiRaidEnabled ? '✅ Aktif' : '❌ Devre Dışı' },
            { name: '📊 Aktivasyon', value: `Koruma sistemini ${settings.antiRaidEnabled ? 'kapatmak' : 'açmak'} için \`${client.config.prefix}raid ${settings.antiRaidEnabled ? 'kapat' : 'aç'}\` yazabilirsiniz.` }
          ],
          user: message.author
        });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda raid koruma ayarlarını güncelledi. (${threshold} kullanıcı / ${timeWindow} saniye)`);
      }
      else if (['iptal', 'cancel'].includes(subCommand)) {
        // Aktif raid korumasını iptal et
        const success = await disableRaidProtection(message.guild);
        
        if (success) {
          const embed = createSuccessEmbed({
            title: 'Raid Koruması İptal Edildi',
            description: 'Aktif raid koruması başarıyla iptal edildi. Sunucu normal haline döndürüldü.',
            user: message.author
          });
          
          message.reply({ embeds: [embed] });
          logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda aktif raid korumasını iptal etti.`);
        } else {
          const errorEmbed = createErrorEmbed({
            title: 'İptal Hatası',
            description: 'Raid koruması iptal edilirken bir hata oluştu veya aktif bir raid koruması bulunmuyor!',
            user: message.author
          });
          message.reply({ embeds: [errorEmbed] });
        }
      }
    } catch (error) {
      logger.error(`Raid komutu hatası: ${error}`);
      const errorEmbed = createErrorEmbed({
        title: 'İşlem Hatası',
        description: 'İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
        user: message.author
      });
      message.reply({ embeds: [errorEmbed] });
    }
  }
};

/**
 * Raid koruma için interaktif menü gösterir
 * @param {Object} client - Discord client
 * @param {Object} message - Mesaj objesi
 */
async function showInteractiveMenu(client, message) {
  try {
    // Sunucu ayarlarını getir
    const settings = await ServerSettings.findOne({ guildId: message.guild.id });
    const isEnabled = settings ? settings.antiRaidEnabled : false;
    
    // Ana menü
    const menuEmbed = createInfoEmbed({
      title: 'Raid Koruma Menüsü',
      description: 'Raid koruma sistemi ile ilgili ne yapmak istiyorsunuz?',
      fields: [
        { name: '🔄 Mevcut Durum', value: isEnabled ? '✅ Aktif' : '❌ Devre Dışı' },
        settings ? { name: '⚠️ Tetikleyici', value: `${settings.joinThreshold || 10} kullanıcı / ${settings.joinTimeWindow || 5} saniye` } : { name: '⚠️ Ayarlar', value: 'Henüz yapılandırılmamış' }
      ],
      user: message.author
    });
    
    // Menü butonları
    const menuButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('raid_toggle')
          .setLabel(isEnabled ? 'Devre Dışı Bırak' : 'Aktifleştir')
          .setStyle(isEnabled ? ButtonStyle.Danger : ButtonStyle.Success)
          .setEmoji(isEnabled ? '🔴' : '🟢'),
        new ButtonBuilder()
          .setCustomId('raid_settings')
          .setLabel('Ayarları Düzenle')
          .setStyle(ButtonStyle.Primary)
          .setEmoji('⚙️'),
        settings && isEnabled ? 
          new ButtonBuilder()
            .setCustomId('raid_cancel')
            .setLabel('Aktif Korumayı İptal Et')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('🚫') : null
      ).components.filter(Boolean); // null değerleri filtrele
    
    // Menüyü gönder
    const menuMessage = await message.reply({
      embeds: [menuEmbed],
      components: [menuButtons]
    });
    
    // Buton tıklamalarını bekle
    const filter = i => i.user.id === message.author.id;
    const collector = menuMessage.createMessageComponentCollector({
      filter,
      componentType: ComponentType.Button,
      time: 60000
    });
    
    collector.on('collect', async interaction => {
      await interaction.deferUpdate();
      
      if (interaction.customId === 'raid_toggle') {
        // Durumu değiştir
        try {
          if (!settings) {
            const newSettings = new ServerSettings({ 
              guildId: message.guild.id,
              antiRaidEnabled: true
            });
            await newSettings.save();
          } else {
            settings.antiRaidEnabled = !settings.antiRaidEnabled;
            await settings.save();
          }
          
          // Başarı mesajı
          const toggledSettings = await ServerSettings.findOne({ guildId: message.guild.id });
          const toggleEmbed = toggledSettings.antiRaidEnabled ?
            createSuccessEmbed({
              title: 'Raid Koruma Aktifleştirildi',
              description: 'Raid koruma sistemi başarıyla aktifleştirildi. Olası raid durumlarına karşı sunucunuz artık korunuyor.',
              fields: [
                { name: '⚠️ Tetikleyici', value: `${toggledSettings.joinThreshold} kullanıcı / ${toggledSettings.joinTimeWindow} saniye` }
              ],
              user: message.author
            }) :
            createWarningEmbed({
              title: 'Raid Koruma Devre Dışı Bırakıldı',
              description: 'Raid koruma sistemi devre dışı bırakıldı. Artık raid durumlarına karşı otomatik koruma sağlanmayacak.',
              user: message.author
            });
          
          await menuMessage.edit({
            embeds: [toggleEmbed],
            components: []
          });
          
          logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda raid koruma sistemini ${toggledSettings.antiRaidEnabled ? 'aktifleştirdi' : 'devre dışı bıraktı'}.`);
        } catch (error) {
          logger.error(`Raid durumu değiştirme hatası: ${error}`);
          const errorEmbed = createErrorEmbed({
            title: 'İşlem Hatası',
            description: 'Ayarlar güncellenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
            user: message.author
          });
          
          await menuMessage.edit({
            embeds: [errorEmbed],
            components: []
          });
        }
      }
      else if (interaction.customId === 'raid_settings') {
        // Ayarları düzenleme menüsünü göster
        const settingsEmbed = createInfoEmbed({
          title: 'Raid Koruma Ayarları',
          description: 'Lütfen aşağıdaki mesaja iki sayı girin:\n1. Kaç kullanıcı (3-50 arası)\n2. Kaç saniye içinde (2-60 arası)\n\nÖrnek: `10 5` (10 kullanıcı / 5 saniye)',
          user: message.author
        });
        
        await menuMessage.edit({
          embeds: [settingsEmbed],
          components: []
        });
        
        // Kullanıcı cevabını bekle
        const msgFilter = m => m.author.id === message.author.id;
        const msgCollector = message.channel.createMessageCollector({
          filter: msgFilter,
          max: 1,
          time: 30000
        });
        
        msgCollector.on('collect', async settingsMsg => {
          // Mesajı sil
          try {
            await settingsMsg.delete();
          } catch (error) {
            // Silme hatası - önemli değil
          }
          
          const args = settingsMsg.content.trim().split(/\s+/);
          if (args.length < 2) {
            const errorEmbed = createErrorEmbed({
              title: 'Geçersiz Giriş',
              description: 'İki sayı girmelisiniz! İşlem iptal edildi.',
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [errorEmbed],
              components: []
            });
            return;
          }
          
          const threshold = parseInt(args[0]);
          const timeWindow = parseInt(args[1]);
          
          if (isNaN(threshold) || threshold < 3 || threshold > 50) {
            const errorEmbed = createErrorEmbed({
              title: 'Geçersiz Değer',
              description: 'Kullanıcı sayısı 3 ile 50 arasında olmalıdır! İşlem iptal edildi.',
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [errorEmbed],
              components: []
            });
            return;
          }
          
          if (isNaN(timeWindow) || timeWindow < 2 || timeWindow > 60) {
            const errorEmbed = createErrorEmbed({
              title: 'Geçersiz Değer',
              description: 'Zaman penceresi 2 ile 60 saniye arasında olmalıdır! İşlem iptal edildi.',
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [errorEmbed],
              components: []
            });
            return;
          }
          
          try {
            // Ayarları güncelle
            if (!settings) {
              const newSettings = new ServerSettings({
                guildId: message.guild.id,
                joinThreshold: threshold,
                joinTimeWindow: timeWindow
              });
              await newSettings.save();
            } else {
              settings.joinThreshold = threshold;
              settings.joinTimeWindow = timeWindow;
              await settings.save();
            }
            
            // Başarı mesajı
            const updatedSettings = await ServerSettings.findOne({ guildId: message.guild.id });
            const successEmbed = createSuccessEmbed({
              title: 'Raid Koruma Ayarları Güncellendi',
              description: `Raid koruma sistemi başarıyla yapılandırıldı. **${threshold}** kullanıcı **${timeWindow}** saniye içinde katılırsa koruma aktifleşecek.`,
              fields: [
                { name: '🔄 Durum', value: updatedSettings.antiRaidEnabled ? '✅ Aktif' : '❌ Devre Dışı' }
              ],
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [successEmbed],
              components: []
            });
            
            logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda raid koruma ayarlarını güncelledi. (${threshold} kullanıcı / ${timeWindow} saniye)`);
          } catch (error) {
            logger.error(`Raid ayarları güncelleme hatası: ${error}`);
            const errorEmbed = createErrorEmbed({
              title: 'İşlem Hatası',
              description: 'Ayarlar güncellenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [errorEmbed],
              components: []
            });
          }
        });
        
        msgCollector.on('end', (collected, reason) => {
          if (reason === 'time' && collected.size === 0) {
            showTimeoutMessage(menuMessage, message.author);
          }
        });
      }
      else if (interaction.customId === 'raid_cancel') {
        // Onay iste
        const confirmEmbed = createWarningEmbed({
          title: 'Raid Korumasını İptal Etmek Üzeresiniz',
          description: 'Aktif raid korumasını iptal etmek istediğinize emin misiniz? Bu işlem, sunucunun güvenlik seviyesini eski haline döndürecektir.',
          user: message.author
        });
        
        const confirmRow = createConfirmCancelRow();
        
        await menuMessage.edit({
          embeds: [confirmEmbed],
          components: [confirmRow]
        });
        
        // Onay bekle
        const confirmFilter = i => i.user.id === message.author.id;
        const confirmCollector = menuMessage.createMessageComponentCollector({
          filter: confirmFilter,
          componentType: ComponentType.Button,
          time: 30000,
          max: 1
        });
        
        confirmCollector.on('collect', async confirmInteraction => {
          await confirmInteraction.deferUpdate();
          
          if (confirmInteraction.customId === 'confirm') {
            try {
              const success = await disableRaidProtection(message.guild);
              
              if (success) {
                const successEmbed = createSuccessEmbed({
                  title: 'Raid Koruması İptal Edildi',
                  description: 'Aktif raid koruması başarıyla iptal edildi. Sunucu normal haline döndürüldü.',
                  user: message.author
                });
                
                await menuMessage.edit({
                  embeds: [successEmbed],
                  components: []
                });
                
                logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda aktif raid korumasını iptal etti.`);
              } else {
                const errorEmbed = createErrorEmbed({
                  title: 'İptal Hatası',
                  description: 'Raid koruması iptal edilirken bir hata oluştu veya aktif bir raid koruması bulunmuyor!',
                  user: message.author
                });
                
                await menuMessage.edit({
                  embeds: [errorEmbed],
                  components: []
                });
              }
            } catch (error) {
              logger.error(`Raid iptal hatası: ${error}`);
              const errorEmbed = createErrorEmbed({
                title: 'İşlem Hatası',
                description: 'Koruma iptal edilirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
                user: message.author
              });
              
              await menuMessage.edit({
                embeds: [errorEmbed],
                components: []
              });
            }
          } else {
            // İptal edildi
            const cancelEmbed = createInfoEmbed({
              title: 'İşlem İptal Edildi',
              description: 'Raid koruması iptal işlemi kullanıcı tarafından iptal edildi.',
              user: message.author
            });
            
            await menuMessage.edit({
              embeds: [cancelEmbed],
              components: []
            });
          }
        });
        
        confirmCollector.on('end', (collected, reason) => {
          if (reason === 'time' && collected.size === 0) {
            showTimeoutMessage(menuMessage, message.author);
          }
        });
      }
    });
    
    collector.on('end', (collected, reason) => {
      if (reason === 'time' && collected.size === 0) {
        showTimeoutMessage(menuMessage, message.author);
      }
    });
  } catch (error) {
    logger.error(`Raid menüsü oluşturma hatası: ${error}`);
    const errorEmbed = createErrorEmbed({
      title: 'Menü Hatası',
      description: 'Menü oluşturulurken bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
      user: message.author
    });
    message.reply({ embeds: [errorEmbed] });
  }
}
