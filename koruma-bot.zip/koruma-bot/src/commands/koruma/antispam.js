const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'antispam',
  aliases: ['spam', 'spamkoruma'],
  description: 'Spam koruma sistemini yapılandırır',
  usage: 'antispam <aç/kapat/ayarla> [mesaj sayısı] [saniye]',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['aç', 'kapat', 'ac', 'on', 'off', 'ayarla', 'setup'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `antispam aç`, `antispam kapat` veya `antispam ayarla` yazmalısın.');
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Alt komuta göre işlem yap
      if (['aç', 'ac', 'on'].includes(subCommand)) {
        settings.antiSpamEnabled = true;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Spam Koruma Aktifleştirildi')
          .setDescription('Spam koruma sistemi başarıyla aktifleştirildi. Olası spam durumlarına karşı sunucunuz artık korunuyor.')
          .addFields(
            { name: '⚠️ Tetikleyici', value: `${settings.spamThreshold} mesaj / ${settings.spamTimeWindow} saniye` },
            { name: '⚙️ Ayarlar', value: `Ayarları değiştirmek için \`${client.config.prefix}antispam ayarla\` komutunu kullanabilirsiniz.` }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından aktifleştirildi`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda spam koruma sistemini aktifleştirdi.`);
      } 
      else if (['kapat', 'off'].includes(subCommand)) {
        settings.antiSpamEnabled = false;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Spam Koruma Devre Dışı Bırakıldı')
          .setDescription('Spam koruma sistemi başarıyla devre dışı bırakıldı. Artık spam durumlarına karşı otomatik koruma sağlanmayacak.')
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından devre dışı bırakıldı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda spam koruma sistemini devre dışı bıraktı.`);
      }
      else if (['ayarla', 'setup'].includes(subCommand)) {
        // Threshold ve zaman penceresi ayarları için ek parametreler olmalı
        if (args.length < 3) {
          return message.reply(`❌ Eksik parametre! Örnek kullanım: \`${client.config.prefix}antispam ayarla 5 3\` (5 mesaj / 3 saniye)`);
        }
        
        const threshold = parseInt(args[1]);
        const timeWindow = parseInt(args[2]);
        
        if (isNaN(threshold) || threshold < 3 || threshold > 20) {
          return message.reply('❌ Mesaj sayısı 3 ile 20 arasında olmalıdır!');
        }
        
        if (isNaN(timeWindow) || timeWindow < 2 || timeWindow > 30) {
          return message.reply('❌ Zaman penceresi 2 ile 30 saniye arasında olmalıdır!');
        }
        
        // Ceza tipi (opsiyonel)
        let punishmentType = 'mute';
        if (args.length >= 4) {
          const inputPunishment = args[3].toLowerCase();
          if (['mute', 'kick', 'ban', 'none'].includes(inputPunishment)) {
            punishmentType = inputPunishment;
          }
        }
        
        settings.spamThreshold = threshold;
        settings.spamTimeWindow = timeWindow;
        settings.spamPunishmentType = punishmentType;
        await settings.save();
        
        const punishmentText = {
          'mute': 'Susturma (5 dakika)',
          'kick': 'Sunucudan Atma',
          'ban': 'Sunucudan Yasaklama',
          'none': 'Ceza Yok (Sadece mesajları sil)'
        };
        
        const embed = new EmbedBuilder()
          .setColor('#0099ff')
          .setTitle('⚙️ Spam Koruma Ayarları Güncellendi')
          .setDescription(`Spam koruma sistemi başarıyla yapılandırıldı. **${threshold}** mesaj **${timeWindow}** saniye içinde gönderilirse koruma aktifleşecek.`)
          .addFields(
            { name: '🔄 Durum', value: settings.antiSpamEnabled ? '✅ Aktif' : '❌ Devre Dışı' },
            { name: '🚫 Ceza Türü', value: punishmentText[punishmentType] },
            { name: '📊 Aktivasyon', value: `Koruma sistemini ${settings.antiSpamEnabled ? 'kapatmak' : 'açmak'} için \`${client.config.prefix}antispam ${settings.antiSpamEnabled ? 'kapat' : 'aç'}\` yazabilirsiniz.` }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda spam koruma ayarlarını güncelledi. (${threshold} mesaj / ${timeWindow} saniye, ceza: ${punishmentType})`);
      }
    } catch (error) {
      logger.error(`Anti-spam komutu hatası: ${error}`);
      message.reply('❌ İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
