const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'durum',
  aliases: ['status', 'korumadurumu'],
  description: 'Sunucunun koruma durumunu gösterir',
  usage: 'durum',
  cooldown: 5,
  guildOnly: true,
  args: false,
  permissions: null,
  async execute(client, message, args) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        return message.reply('❌ Bu sunucu için herhangi bir koruma ayarı yapılmamış!');
      }
      
      // Durum emoji belirleme
      const statusEmoji = {
        true: '✅',
        false: '❌'
      };
      
      // Ceza türü belirleme
      const punishmentType = {
        'ban': '🔨 Yasaklama',
        'kick': '👢 Atma',
        'none': '🔍 Sadece İzleme'
      };
      
      const embed = new EmbedBuilder()
        .setColor('#0099ff')
        .setTitle('🛡️ Sunucu Koruma Durumu')
        .setDescription(`**${message.guild.name}** sunucusu için koruma sistemi durumu:`)
        .addFields(
          { name: '📊 Genel Durum', value: `Koruma: ${statusEmoji[settings.protectionEnabled]} ${settings.protectionEnabled ? 'Aktif' : 'Devre Dışı'}\nYaptırım: ${punishmentType[settings.punishmentType]}\nLog Kanalı: ${settings.logChannelId ? `<#${settings.logChannelId}>` : '❌ Ayarlanmamış'}` },
          { name: '⚡ Koruma Modülleri', value: `
            Kanal Silme: ${statusEmoji[settings.protectionLevels.channelDelete]}
            Rol Silme: ${statusEmoji[settings.protectionLevels.roleDelete]}
            Rol Güncelleme: ${statusEmoji[settings.protectionLevels.roleUpdate]}
            Üye Yasaklama: ${statusEmoji[settings.protectionLevels.memberBan]}
            Üye Atma: ${statusEmoji[settings.protectionLevels.memberKick]}
            Bot Ekleme: ${statusEmoji[settings.protectionLevels.botAdd]}
          ` },
          { name: '🚨 Anti-Raid', value: `Durum: ${statusEmoji[settings.antiRaidEnabled]} ${settings.antiRaidEnabled ? 'Aktif' : 'Devre Dışı'}\nTetikleyici: ${settings.joinThreshold} kullanıcı / ${settings.joinTimeWindow} saniye` }
        )
        .addFields(
          { name: '🔐 Güvenli Liste', value: `Kullanıcılar: ${settings.whitelistedUsers.length} kişi\nRoller: ${settings.whitelistedRoles.length} rol` }
        )
        .setTimestamp()
        .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
      
      message.reply({ embeds: [embed] });
      
      logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunun koruma durumunu görüntüledi.`);
    } catch (error) {
      logger.error(`Durum komutu hatası: ${error}`);
      message.reply('❌ Koruma durumu görüntülenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
