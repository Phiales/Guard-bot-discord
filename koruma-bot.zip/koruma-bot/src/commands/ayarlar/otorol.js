const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'otorol',
  aliases: ['autorole', 'otomatikrol'],
  description: 'Sunucuya yeni katılan üyelere otomatik rol verme sistemini yönetir',
  usage: 'otorol <aç/kapat/rol/botrol> [@rol]',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['aç', 'kapat', 'ac', 'on', 'off', 'rol', 'role', 'botrol', 'botrole'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `otorol aç`, `otorol kapat`, `otorol rol` veya `otorol botrol` kullanmalısın.');
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Alt komuta göre işlem yap
      if (['aç', 'ac', 'on'].includes(subCommand)) {
        // Rol kontrolü
        if (!settings.autoRoleId) {
          return message.reply(`❌ Önce otomatik verilecek rolü ayarlamalısın! \`${client.config.prefix}otorol rol @rol\` komutunu kullan.`);
        }
        
        settings.autoRoleEnabled = true;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Otomatik Rol Sistemi Aktifleştirildi')
          .setDescription('Otomatik rol sistemi başarıyla aktifleştirildi. Artık sunucuya katılan üyelere otomatik rol verilecek.')
          .addFields(
            { name: '🔰 Üye Rolü', value: `<@&${settings.autoRoleId}>` },
            { name: '🤖 Bot Rolü', value: settings.botRoleId ? `<@&${settings.botRoleId}>` : '❌ Ayarlanmamış' }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından aktifleştirildi`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda otomatik rol sistemini aktifleştirdi.`);
      } 
      else if (['kapat', 'off'].includes(subCommand)) {
        settings.autoRoleEnabled = false;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Otomatik Rol Sistemi Devre Dışı Bırakıldı')
          .setDescription('Otomatik rol sistemi devre dışı bırakıldı. Artık sunucuya katılan üyelere otomatik rol verilmeyecek.')
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından devre dışı bırakıldı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda otomatik rol sistemini devre dışı bıraktı.`);
      }
      else if (['rol', 'role'].includes(subCommand)) {
        // Rol etiketi kontrolü
        if (!message.mentions.roles.first()) {
          return message.reply('❌ Geçerli bir rol etiketlemelisin!');
        }
        
        const role = message.mentions.roles.first();
        
        // @everyone rolü kontrolü
        if (role.id === message.guild.id) {
          return message.reply('❌ @everyone rolünü otomatik rol olarak ayarlayamazsın!');
        }
        
        settings.autoRoleId = role.id;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Otomatik Üye Rolü Ayarlandı')
          .setDescription(`Otomatik verilecek üye rolü başarıyla ${role} olarak ayarlandı.`)
          .addFields(
            { name: '🔄 Durum', value: settings.autoRoleEnabled ? '✅ Aktif' : '❌ Devre Dışı' },
            { name: '📝 Bilgi', value: `Sistemi ${settings.autoRoleEnabled ? 'kapatmak' : 'açmak'} için \`${client.config.prefix}otorol ${settings.autoRoleEnabled ? 'kapat' : 'aç'}\` komutunu kullanabilirsiniz.` }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda otomatik üye rolünü ${role.name} olarak ayarladı.`);
      }
      else if (['botrol', 'botrole'].includes(subCommand)) {
        // Rol etiketi kontrolü
        if (!message.mentions.roles.first()) {
          return message.reply('❌ Geçerli bir rol etiketlemelisin!');
        }
        
        const role = message.mentions.roles.first();
        
        // @everyone rolü kontrolü
        if (role.id === message.guild.id) {
          return message.reply('❌ @everyone rolünü otomatik bot rolü olarak ayarlayamazsın!');
        }
        
        settings.botRoleId = role.id;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Otomatik Bot Rolü Ayarlandı')
          .setDescription(`Otomatik verilecek bot rolü başarıyla ${role} olarak ayarlandı.`)
          .addFields(
            { name: '🔄 Durum', value: settings.autoRoleEnabled ? '✅ Aktif' : '❌ Devre Dışı' },
            { name: '📝 Bilgi', value: `Sistemi ${settings.autoRoleEnabled ? 'kapatmak' : 'açmak'} için \`${client.config.prefix}otorol ${settings.autoRoleEnabled ? 'kapat' : 'aç'}\` komutunu kullanabilirsiniz.` }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda otomatik bot rolünü ${role.name} olarak ayarladı.`);
      }
    } catch (error) {
      logger.error(`Otorol komutu hatası: ${error}`);
      message.reply('❌ İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
