const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'ceza',
  aliases: ['punishment', 'yaptırım'],
  description: 'Koruma sistemi ihlal cezasını ayarlar',
  usage: 'ceza <ban/kick/none>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const punishmentType = args[0].toLowerCase();
    
    if (!['ban', 'kick', 'none', 'yok'].includes(punishmentType)) {
      return message.reply('❌ Geçersiz ceza türü! `ban`, `kick` veya `none` değerlerinden birini kullanmalısın.');
    }
    
    // "none" ve "yok" için aynı değeri kullan
    const normalizedPunishment = (['none', 'yok'].includes(punishmentType)) ? 'none' : punishmentType;
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ 
          guildId: message.guild.id,
          punishmentType: normalizedPunishment
        });
      } else {
        settings.punishmentType = normalizedPunishment;
      }
      
      await settings.save();
      
      // Ceza türüne göre ikon ve açıklama belirle
      let icon, description, color;
      
      switch(normalizedPunishment) {
        case 'ban':
          icon = '🔨';
          description = 'Koruma ihlali yapan kullanıcılar sunucudan yasaklanacak.';
          color = '#FF0000';
          break;
        case 'kick':
          icon = '👢';
          description = 'Koruma ihlali yapan kullanıcılar sunucudan atılacak.';
          color = '#FFA500';
          break;
        case 'none':
          icon = '🔍';
          description = 'Koruma ihlalleri log kanalına bildirilecek fakat otomatik ceza uygulanmayacak.';
          color = '#0099ff';
          break;
      }
      
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(`${icon} Ceza Türü Ayarlandı`)
        .setDescription(`Koruma sistemi ceza türü başarıyla **${normalizedPunishment}** olarak ayarlandı.\n\n${description}`)
        .setTimestamp()
        .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
      
      message.reply({ embeds: [embed] });
      
      logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda ceza türünü ${normalizedPunishment} olarak ayarladı.`);
    } catch (error) {
      logger.error(`Ceza komutu hatası: ${error}`);
      message.reply('❌ Ayarlar güncellenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
