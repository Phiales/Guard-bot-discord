const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'logkanal',
  aliases: ['logchannel', 'log'],
  description: 'Koruma sistemi log kanalını ayarlar',
  usage: 'logkanal <#kanal/sıfırla>',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Sıfırlama seçeneği
      if (['sıfırla', 'sifirla', 'reset'].includes(args[0].toLowerCase())) {
        settings.logChannelId = null;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('🗑️ Log Kanalı Sıfırlandı')
          .setDescription('Koruma sistemi log kanalı başarıyla sıfırlandı. Artık log mesajları gönderilmeyecek.')
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından sıfırlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda log kanalını sıfırladı.`);
        return;
      }
      
      // Kanal etiketini kontrol et
      const channel = message.mentions.channels.first();
      
      if (!channel) {
        return message.reply('❌ Geçerli bir kanal etiketlemelisin veya `sıfırla` yazmalısın!');
      }
      
      // Kanalın metin kanalı olduğunu kontrol et
      if (channel.type !== 0) { // 0 = TEXT_CHANNEL
        return message.reply('❌ Sadece metin kanalları log kanalı olarak ayarlanabilir!');
      }
      
      // Ayarları güncelle
      settings.logChannelId = channel.id;
      await settings.save();
      
      const embed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('✅ Log Kanalı Ayarlandı')
        .setDescription(`Koruma sistemi log kanalı başarıyla ${channel} olarak ayarlandı. Tüm koruma olayları artık bu kanala gönderilecek.`)
        .setTimestamp()
        .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
      
      message.reply({ embeds: [embed] });
      
      // Test mesajı gönder
      channel.send({
        embeds: [{
          title: '🛡️ Log Sistemi Aktif',
          description: 'Koruma sistemi log kanalı başarıyla ayarlandı. Tüm koruma olayları artık bu kanala gönderilecek.',
          color: 0x00FF00,
          timestamp: new Date()
        }]
      });
      
      logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda log kanalını ${channel.name} olarak ayarladı.`);
    } catch (error) {
      logger.error(`Log kanal komutu hatası: ${error}`);
      message.reply('❌ Ayarlar güncellenirken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
