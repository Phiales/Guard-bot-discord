const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const logger = require('../../utils/logger');
const { getRandomImage, getRandomGif, getImageByQuery, getGifByQuery, resizeImageForEmoji, getImageBufferFromUrl } = require('../../utils/imageProcessor');

module.exports = {
  name: 'emoji-ekle',
  aliases: ['emojiekle', 'addemoji'],
  description: 'Sunucuya emoji ekler (rastgele veya arama sorgusuyla)',
  usage: 'emoji-ekle',
  cooldown: 10,
  guildOnly: true,
  args: false,
  permissions: 'ManageEmojisAndStickers',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('ManageEmojisAndStickers')) {
      return message.reply('❌ Bu komutu kullanmak için **Emoji ve Çıkartmaları Yönet** yetkisine sahip olmalısın!');
    }

    try {
      // Ana menü
      const mainMenu = new EmbedBuilder()
        .setColor('#FF9300')
        .setTitle('🎭 Emoji Ekleme Sihirbazı')
        .setDescription('Sunucunuza nasıl emoji eklemek istersiniz?')
        .addFields(
          { name: '🎲 Rastgele', value: 'İnternetten rastgele bir görsel veya GIF ile emoji oluşturur.' },
          { name: '🔍 Parametre ile Arama', value: 'Belirttiğiniz kelime veya cümleye göre görsel bulup emoji oluşturur.' }
        )
        .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
      
      // Menü butonları
      const mainMenuButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('random')
            .setLabel('Rastgele')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('🎲'),
          new ButtonBuilder()
            .setCustomId('search')
            .setLabel('Arama')
            .setStyle(ButtonStyle.Success)
            .setEmoji('🔍'),
          new ButtonBuilder()
            .setCustomId('cancel')
            .setLabel('İptal')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('❌')
        );
      
      // Ana menüyü gönder
      const menuMessage = await message.reply({
        embeds: [mainMenu],
        components: [mainMenuButtons]
      });
      
      // Buton tıklamalarını bekle
      const mainFilter = i => i.user.id === message.author.id;
      const mainCollector = menuMessage.createMessageComponentCollector({
        filter: mainFilter,
        componentType: ComponentType.Button,
        time: 60000
      });
      
      mainCollector.on('collect', async interaction => {
        // Önce etkileşimi ertele
        await interaction.deferUpdate();
        
        if (interaction.customId === 'cancel') {
          mainCollector.stop('cancelled');
          return;
        }
        
        // Rastgele emoji seçeneği
        if (interaction.customId === 'random') {
          // Türü seçme menüsü
          const typeMenu = new EmbedBuilder()
            .setColor('#FF9300')
            .setTitle('🎭 Emoji Türü Seçimi')
            .setDescription('Rastgele bir emoji oluşturmak için hangi tür görseli tercih edersiniz?')
            .addFields(
              { name: '📷 Fotoğraf', value: 'Hareketsiz bir görsel ile emoji oluşturur.' },
              { name: '🎞️ GIF', value: 'Hareketli bir GIF ile emoji oluşturur.' }
            )
            .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
          
          // Tür butonları
          const typeButtons = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('photo')
                .setLabel('Fotoğraf')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('📷'),
              new ButtonBuilder()
                .setCustomId('gif')
                .setLabel('GIF')
                .setStyle(ButtonStyle.Success)
                .setEmoji('🎞️'),
              new ButtonBuilder()
                .setCustomId('back')
                .setLabel('Geri')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('◀️')
            );
          
          // Tür menüsünü gönder
          await menuMessage.edit({
            embeds: [typeMenu],
            components: [typeButtons]
          });
          
          // Türü bekleme koleksiyoncusu
          const typeCollector = menuMessage.createMessageComponentCollector({
            filter: mainFilter,
            componentType: ComponentType.Button,
            time: 60000
          });
          
          typeCollector.on('collect', async typeInteraction => {
            await typeInteraction.deferUpdate();
            
            if (typeInteraction.customId === 'back') {
              // Ana menüye dön
              await menuMessage.edit({
                embeds: [mainMenu],
                components: [mainMenuButtons]
              });
              typeCollector.stop();
              return;
            }
            
            // Emoji oluşturma durumu
            const loadingEmbed = new EmbedBuilder()
              .setColor('#FFA500')
              .setTitle('⏳ Emoji Oluşturuluyor')
              .setDescription('Görsel aranıyor ve emoji hazırlanıyor. Lütfen bekleyin...')
              .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
            
            await menuMessage.edit({
              embeds: [loadingEmbed],
              components: []
            });
            
            try {
              // Rastgele bir emoji ismi oluştur
              const emojiName = `emoji_${Math.floor(Math.random() * 1000)}`;
              let imageUrl;
              
              if (typeInteraction.customId === 'photo') {
                imageUrl = await getRandomImage();
              } else {
                imageUrl = await getRandomGif();
              }
              
              // Görseli indir ve emoji için yeniden boyutlandır
              const imageBuffer = await getImageBufferFromUrl(imageUrl);
              const resizedBuffer = await resizeImageForEmoji(imageBuffer);
              
              // Emojiyi sunucuya ekle
              const emoji = await message.guild.emojis.create({
                attachment: resizedBuffer,
                name: emojiName
              });
              
              // Başarı mesajı
              const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('✅ Emoji Başarıyla Oluşturuldu')
                .setDescription(`Yeni emoji: ${emoji} (${emoji.name}) başarıyla sunucuya eklendi!`)
                .setThumbnail(`https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? 'gif' : 'png'}?size=128`)
                .setFooter({ text: `${message.author.tag} tarafından eklendi`, iconURL: message.author.displayAvatarURL() });
              
              await menuMessage.edit({
                embeds: [successEmbed],
                components: []
              });
              
              logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusuna rastgele bir emoji ekledi.`);
            } catch (error) {
              logger.error(`Emoji oluşturma hatası: ${error}`);
              
              // Hata mesajı
              const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Emoji Oluşturulamadı')
                .setDescription(`Emoji oluşturulurken bir hata oluştu: ${error.message}`)
                .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
              
              await menuMessage.edit({
                embeds: [errorEmbed],
                components: []
              });
            }
            
            typeCollector.stop();
          });
          
          typeCollector.on('end', (collected, reason) => {
            if (reason === 'time') {
              const timeoutEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('⏱️ Zaman Aşımı')
                .setDescription('İşlem zaman aşımına uğradı. Lütfen komutu tekrar çalıştırın.')
                .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
              
              menuMessage.edit({
                embeds: [timeoutEmbed],
                components: []
              });
            }
          });
          
          mainCollector.stop();
        }
        // Arama ile emoji seçeneği
        else if (interaction.customId === 'search') {
          // Arama sorgusunu sormak için gönder
          const searchPromptEmbed = new EmbedBuilder()
            .setColor('#FF9300')
            .setTitle('🔍 Emoji Arama')
            .setDescription('Lütfen arayacağınız kelime veya cümleyi yazın.\n\n⚠️ **30 saniye içinde yazmadığınız takdirde işlem iptal edilecektir.**')
            .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
          
          await menuMessage.edit({
            embeds: [searchPromptEmbed],
            components: []
          });
          
          // Arama sorgusunu bekle
          const msgFilter = m => m.author.id === message.author.id;
          const msgCollector = message.channel.createMessageCollector({
            filter: msgFilter,
            max: 1,
            time: 30000
          });
          
          msgCollector.on('collect', async queryMsg => {
            const searchQuery = queryMsg.content.trim();
            
            // Sorguyu sildirme deneme
            try {
              await queryMsg.delete();
            } catch (error) {
              // Silme hatası - önemli değil, devam et
            }
            
            if (searchQuery.length < 2) {
              const invalidEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Geçersiz Sorgu')
                .setDescription('Arama sorgusu en az 2 karakter olmalıdır.')
                .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
              
              await menuMessage.edit({
                embeds: [invalidEmbed],
                components: []
              });
              return;
            }
            
            // Tür seçme menüsü
            const searchTypeMenu = new EmbedBuilder()
              .setColor('#FF9300')
              .setTitle('🎭 Emoji Türü Seçimi')
              .setDescription(`**Arama:** \`${searchQuery}\`\n\nBu arama terimi için hangi tür görseli tercih edersiniz?`)
              .addFields(
                { name: '📷 Fotoğraf', value: 'Hareketsiz bir görsel ile emoji oluşturur.' },
                { name: '🎞️ GIF', value: 'Hareketli bir GIF ile emoji oluşturur.' }
              )
              .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
            
            // Tür butonları
            const searchTypeButtons = new ActionRowBuilder()
              .addComponents(
                new ButtonBuilder()
                  .setCustomId('search_photo')
                  .setLabel('Fotoğraf')
                  .setStyle(ButtonStyle.Primary)
                  .setEmoji('📷'),
                new ButtonBuilder()
                  .setCustomId('search_gif')
                  .setLabel('GIF')
                  .setStyle(ButtonStyle.Success)
                  .setEmoji('🎞️'),
                new ButtonBuilder()
                  .setCustomId('search_back')
                  .setLabel('Geri')
                  .setStyle(ButtonStyle.Secondary)
                  .setEmoji('◀️')
              );
            
            // Tür menüsünü gönder
            await menuMessage.edit({
              embeds: [searchTypeMenu],
              components: [searchTypeButtons]
            });
            
            // Türü bekleme koleksiyoncusu
            const searchTypeCollector = menuMessage.createMessageComponentCollector({
              filter: mainFilter,
              componentType: ComponentType.Button,
              time: 60000
            });
            
            searchTypeCollector.on('collect', async searchTypeInteraction => {
              await searchTypeInteraction.deferUpdate();
              
              if (searchTypeInteraction.customId === 'search_back') {
                // Ana menüye dön
                await menuMessage.edit({
                  embeds: [mainMenu],
                  components: [mainMenuButtons]
                });
                searchTypeCollector.stop();
                return;
              }
              
              // Emoji oluşturma durumu
              const searchLoadingEmbed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('⏳ Emoji Oluşturuluyor')
                .setDescription(`"${searchQuery}" ile ilgili görsel aranıyor ve emoji hazırlanıyor. Lütfen bekleyin...`)
                .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
              
              await menuMessage.edit({
                embeds: [searchLoadingEmbed],
                components: []
              });
              
              try {
                // Emoji ismi oluştur (sorgudan)
                let emojiName = searchQuery.toLowerCase().replace(/[^a-z0-9]/gi, '_');
                if (emojiName.length > 20) emojiName = emojiName.substring(0, 20);
                if (emojiName.length < 2) emojiName = `emoji_${Math.floor(Math.random() * 1000)}`;
                
                let imageUrl;
                
                if (searchTypeInteraction.customId === 'search_photo') {
                  imageUrl = await getImageByQuery(searchQuery);
                } else {
                  imageUrl = await getGifByQuery(searchQuery);
                }
                
                // Görseli indir ve emoji için yeniden boyutlandır
                const imageBuffer = await getImageBufferFromUrl(imageUrl);
                const resizedBuffer = await resizeImageForEmoji(imageBuffer);
                
                // Emojiyi sunucuya ekle
                const emoji = await message.guild.emojis.create({
                  attachment: resizedBuffer,
                  name: emojiName
                });
                
                // Başarı mesajı
                const searchSuccessEmbed = new EmbedBuilder()
                  .setColor('#00FF00')
                  .setTitle('✅ Emoji Başarıyla Oluşturuldu')
                  .setDescription(`"${searchQuery}" araması için yeni emoji: ${emoji} (${emoji.name}) başarıyla sunucuya eklendi!`)
                  .setThumbnail(`https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? 'gif' : 'png'}?size=128`)
                  .setFooter({ text: `${message.author.tag} tarafından eklendi`, iconURL: message.author.displayAvatarURL() });
                
                await menuMessage.edit({
                  embeds: [searchSuccessEmbed],
                  components: []
                });
                
                logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusuna "${searchQuery}" aramasıyla bir emoji ekledi.`);
              } catch (error) {
                logger.error(`Emoji oluşturma hatası: ${error}`);
                
                // Hata mesajı
                const searchErrorEmbed = new EmbedBuilder()
                  .setColor('#FF0000')
                  .setTitle('❌ Emoji Oluşturulamadı')
                  .setDescription(`Emoji oluşturulurken bir hata oluştu: ${error.message}`)
                  .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
                
                await menuMessage.edit({
                  embeds: [searchErrorEmbed],
                  components: []
                });
              }
              
              searchTypeCollector.stop();
            });
            
            searchTypeCollector.on('end', (collected, reason) => {
              if (reason === 'time') {
                const timeoutEmbed = new EmbedBuilder()
                  .setColor('#FF0000')
                  .setTitle('⏱️ Zaman Aşımı')
                  .setDescription('İşlem zaman aşımına uğradı. Lütfen komutu tekrar çalıştırın.')
                  .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
                
                menuMessage.edit({
                  embeds: [timeoutEmbed],
                  components: []
                });
              }
            });
          });
          
          msgCollector.on('end', (collected, reason) => {
            if (reason === 'time' && collected.size === 0) {
              const timeoutEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('⏱️ Zaman Aşımı')
                .setDescription('Arama sorgusu yazma süresi doldu. Lütfen komutu tekrar çalıştırın.')
                .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
              
              menuMessage.edit({
                embeds: [timeoutEmbed],
                components: []
              });
            }
          });
          
          mainCollector.stop();
        }
      });
      
      mainCollector.on('end', (collected, reason) => {
        if (reason === 'time') {
          const timeoutEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('⏱️ Zaman Aşımı')
            .setDescription('İşlem zaman aşımına uğradı. Lütfen komutu tekrar çalıştırın.')
            .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });
          
          menuMessage.edit({
            embeds: [timeoutEmbed],
            components: []
          });
        } else if (reason === 'cancelled') {
          const cancelEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('❌ İşlem İptal Edildi')
            .setDescription('Emoji ekleme işlemi iptal edildi.')
            .setFooter({ text: `${message.author.tag} tarafından iptal edildi`, iconURL: message.author.displayAvatarURL() });
          
          menuMessage.edit({
            embeds: [cancelEmbed],
            components: []
          });
        }
      });
    } catch (error) {
      logger.error(`Emoji ekleme komutu hatası: ${error}`);
      message.reply('❌ Bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
