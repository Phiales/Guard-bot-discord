const { EmbedBuilder } = require('discord.js');
const ServerSettings = require('../../models/serverSettings');
const logger = require('../../utils/logger');

module.exports = {
  name: 'hosgeldin',
  aliases: ['welcome', 'karşılama'],
  description: 'Sunucuya yeni katılan üyelere hoşgeldin mesajı ayarlarını yönetir',
  usage: 'hosgeldin <aç/kapat/mesaj/kanal> [#kanal/mesaj]',
  cooldown: 5,
  guildOnly: true,
  args: true,
  permissions: 'Administrator',
  async execute(client, message, args) {
    // Yetki kontrolü
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('❌ Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısın!');
    }

    const subCommand = args[0].toLowerCase();
    
    if (!['aç', 'kapat', 'ac', 'mesaj', 'kanal', 'on', 'off', 'message', 'channel'].includes(subCommand)) {
      return message.reply('❌ Geçersiz parametre! `hosgeldin aç`, `hosgeldin kapat`, `hosgeldin mesaj` veya `hosgeldin kanal` kullanmalısın.');
    }
    
    try {
      // Sunucu ayarlarını getir veya oluştur
      let settings = await ServerSettings.findOne({ guildId: message.guild.id });
      
      if (!settings) {
        settings = new ServerSettings({ guildId: message.guild.id });
      }
      
      // Eğer welcomeEnabled özelliği yoksa model şemasına ekle
      if (settings.welcomeEnabled === undefined) {
        settings.welcomeEnabled = false;
        settings.welcomeChannelId = null;
        settings.welcomeMessage = 'Hoş geldin {user}! **{server}** sunucusuna katıldın. Seninle birlikte {memberCount} kişi olduk!';
      }
      
      // Alt komuta göre işlem yap
      if (['aç', 'ac', 'on'].includes(subCommand)) {
        // Kanal kontrolü
        if (!settings.welcomeChannelId) {
          return message.reply(`❌ Önce hoşgeldin kanalını ayarlamalısın! \`${client.config.prefix}hosgeldin kanal #kanal\` komutunu kullan.`);
        }
        
        settings.welcomeEnabled = true;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Hoşgeldin Sistemi Aktifleştirildi')
          .setDescription('Hoşgeldin mesajları sistemi başarıyla aktifleştirildi. Artık sunucuya katılan üyelere otomatik mesaj gönderilecek.')
          .addFields(
            { name: '📝 Mesaj', value: settings.welcomeMessage },
            { name: '📢 Kanal', value: `<#${settings.welcomeChannelId}>` }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından aktifleştirildi`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda hoşgeldin sistemini aktifleştirdi.`);
      } 
      else if (['kapat', 'off'].includes(subCommand)) {
        settings.welcomeEnabled = false;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Hoşgeldin Sistemi Devre Dışı Bırakıldı')
          .setDescription('Hoşgeldin mesajları sistemi devre dışı bırakıldı. Artık sunucuya katılan üyelere otomatik mesaj gönderilmeyecek.')
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından devre dışı bırakıldı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda hoşgeldin sistemini devre dışı bıraktı.`);
      }
      else if (['kanal', 'channel'].includes(subCommand)) {
        // Kanal etiketi kontrolü
        if (!message.mentions.channels.first()) {
          return message.reply('❌ Geçerli bir kanal etiketlemelisin!');
        }
        
        const channel = message.mentions.channels.first();
        
        // Kanalın metin kanalı olduğunu kontrol et
        if (channel.type !== 0) { // 0 = TEXT_CHANNEL
          return message.reply('❌ Sadece metin kanalları hoşgeldin kanalı olarak ayarlanabilir!');
        }
        
        settings.welcomeChannelId = channel.id;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Hoşgeldin Kanalı Ayarlandı')
          .setDescription(`Hoşgeldin kanalı başarıyla ${channel} olarak ayarlandı.`)
          .addFields(
            { name: '📝 Hoşgeldin Mesajı', value: settings.welcomeMessage },
            { name: '🔄 Durum', value: settings.welcomeEnabled ? '✅ Aktif' : '❌ Devre Dışı' }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda hoşgeldin kanalını ${channel.name} olarak ayarladı.`);
      }
      else if (['mesaj', 'message'].includes(subCommand)) {
        // Mesaj kontrolü
        if (args.length < 2) {
          return message.reply(`❌ Bir hoşgeldin mesajı belirtmelisin! Örnek: \`${client.config.prefix}hosgeldin mesaj Hoş geldin {user}!\``);
        }
        
        const welcomeMessage = args.slice(1).join(' ');
        
        if (welcomeMessage.length > 300) {
          return message.reply('❌ Hoşgeldin mesajı en fazla 300 karakter olabilir!');
        }
        
        settings.welcomeMessage = welcomeMessage;
        await settings.save();
        
        const embed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Hoşgeldin Mesajı Ayarlandı')
          .setDescription('Hoşgeldin mesajı başarıyla ayarlandı.')
          .addFields(
            { name: '📝 Yeni Mesaj', value: welcomeMessage },
            { name: '📌 Kullanılabilir Değişkenler', value: '`{user}` - Kullanıcı etiketi\n`{username}` - Kullanıcı adı\n`{server}` - Sunucu adı\n`{memberCount}` - Toplam üye sayısı' },
            { name: '🔄 Durum', value: settings.welcomeEnabled ? '✅ Aktif' : '❌ Devre Dışı' }
          )
          .setTimestamp()
          .setFooter({ text: `${message.author.tag} tarafından ayarlandı`, iconURL: message.author.displayAvatarURL() });
        
        message.reply({ embeds: [embed] });
        logger.info(`${message.author.tag} kullanıcısı ${message.guild.name} sunucusunda hoşgeldin mesajını güncelledi.`);
      }
    } catch (error) {
      logger.error(`Hoşgeldin komutu hatası: ${error}`);
      message.reply('❌ İşlem yapılırken bir hata oluştu! Lütfen daha sonra tekrar deneyin.');
    }
  }
};
