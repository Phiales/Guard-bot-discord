const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'yardim',
  aliases: ['help', 'komutlar', 'y'],
  description: 'Tüm komutları listeler',
  usage: 'yardim [komut]',
  cooldown: 5,
  guildOnly: false,
  args: false,
  permissions: null,
  async execute(client, message, args) {
    const { commands } = client;
    const prefix = client.config.prefix;
    
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('📚 KorumaBot Yardım Menüsü')
      .setDescription(`Tüm komutlar için **${prefix}yardim** yazabilirsiniz.\nBir komut hakkında detaylı bilgi için **${prefix}yardim [komut]** yazabilirsiniz.`)
      .setThumbnail(client.user.displayAvatarURL())
      .setTimestamp()
      .setFooter({ text: `${message.author.tag} tarafından istendi`, iconURL: message.author.displayAvatarURL() });

    if (!args.length) {
      // Komut kategorilerini gruplandır
      const categories = {
        "koruma": "🛡️ Koruma Komutları",
        "ayarlar": "⚙️ Ayar Komutları",
        "yardim": "ℹ️ Yardım Komutları"
      };
      
      // Her kategori için alanları hazırla
      for (const [categoryName, categoryTitle] of Object.entries(categories)) {
        // Kategoriye ait komutları bul
        const categoryCommands = commands.filter(cmd => cmd.name && cmd.name !== 'help' && 
          // Komutun dosya yolu kategoriye ait mi kontrol et
          // Not: Bu, her komut dosyasının kategori adıyla aynı isimde bir klasörde olmasını gerektirir
          __filename.includes(`\\${categoryName}\\`) || __filename.includes(`/${categoryName}/`));
        
        if (categoryCommands.size > 0) {
          embed.addFields({
            name: categoryTitle,
            value: categoryCommands.map(cmd => `\`${prefix}${cmd.name}\`: ${cmd.description}`).join('\n')
          });
        }
      }
      
      return message.reply({ embeds: [embed] });
    }

    // Belirli bir komut için yardım görüntüle
    const name = args[0].toLowerCase();
    const command = commands.get(name) || 
                    commands.find(c => c.aliases && c.aliases.includes(name));

    if (!command) {
      return message.reply('❌ Böyle bir komut bulunamadı!');
    }

    embed.setTitle(`📖 Komut: ${prefix}${command.name}`);
    embed.setDescription(`${command.description || 'Açıklama yok'}`);
    
    if (command.aliases) embed.addFields({ name: '🔄 Alternatif İsimler', value: command.aliases.join(', ') });
    if (command.usage) embed.addFields({ name: '📝 Kullanım', value: `${prefix}${command.name} ${command.usage}` });
    if (command.cooldown) embed.addFields({ name: '⏱️ Bekleme Süresi', value: `${command.cooldown} saniye` });
    if (command.permissions) embed.addFields({ name: '🔑 Gerekli Yetkiler', value: command.permissions });
    
    message.reply({ embeds: [embed] });
  }
};
