const mongoose = require('mongoose');

const serverSettingsSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true
  },
  protectionEnabled: {
    type: Boolean,
    default: true
  },
  punishmentType: {
    type: String,
    enum: ['ban', 'kick', 'none'],
    default: 'kick'
  },
  logChannelId: {
    type: String,
    default: null
  },
  whitelistedUsers: [{
    type: String
  }],
  whitelistedRoles: [{
    type: String
  }],
  protectionLevels: {
    channelDelete: {
      type: Boolean,
      default: true
    },
    channelCreate: {
      type: Boolean,
      default: true
    },
    channelUpdate: {
      type: Boolean,
      default: true
    },
    roleDelete: {
      type: Boolean,
      default: true
    },
    roleCreate: {
      type: Boolean,
      default: true
    },
    roleUpdate: {
      type: Boolean,
      default: true
    },
    memberBan: {
      type: Boolean,
      default: true
    },
    webhookCreate: {
      type: Boolean,
      default: true
    },
    memberKick: {
      type: Boolean,
      default: true
    },
    botAdd: {
      type: Boolean,
      default: true
    }
  },
  recoveryOptions: {
    channelRecovery: {
      type: Boolean,
      default: true
    },
    roleRecovery: {
      type: Boolean,
      default: true
    },
    banRecovery: {
      type: Boolean,
      default: true
    }
  },
  antiRaidEnabled: {
    type: Boolean,
    default: false
  },
  joinThreshold: {
    type: Number,
    default: 10
  },
  joinTimeWindow: {
    type: Number, // in seconds
    default: 10
  },
  backupEnabled: {
    type: Boolean,
    default: false
  },
  lastBackupDate: {
    type: Date,
    default: null
  },
  antiSpamEnabled: {
    type: Boolean,
    default: false
  },
  spamThreshold: {
    type: Number,
    default: 5
  },
  spamTimeWindow: {
    type: Number, // in seconds
    default: 5
  },
  spamPunishmentType: {
    type: String,
    enum: ['mute', 'kick', 'ban', 'none'],
    default: 'mute'
  },
  welcomeEnabled: {
    type: Boolean,
    default: false
  },
  welcomeChannelId: {
    type: String,
    default: null
  },
  welcomeMessage: {
    type: String,
    default: 'Hoş geldin {user}! **{server}** sunucusuna katıldın. Seninle birlikte {memberCount} kişi olduk!'
  },
  autoRoleEnabled: {
    type: Boolean,
    default: false
  },
  autoRoleId: {
    type: String,
    default: null
  },
  botRoleId: {
    type: String,
    default: null
  },
  quarantineRoleId: {
    type: String,
    default: null
  }
}, { timestamps: true });

module.exports = mongoose.model('ServerSettings', serverSettingsSchema);
