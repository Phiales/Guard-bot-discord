const { AuditLogEvent } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'webhookUpdate',
  once: false,
  async execute(client, channel) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: channel.guild.id });
      if (!settings || !settings.protectionEnabled || !settings.protectionLevels.webhookCreate) return;

      // Denetim kaydını kontrol et (webhook oluşturma/silme/güncelleme)
      const auditLogs = await channel.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.WebhookCreate
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, channel.guild.id, 'webhookCreate')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için webhook oluşturmasına izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${channel.name} kanalında izinsiz webhook oluşturdu!`);
      
      // Webhookları al ve sil
      const webhooks = await channel.fetchWebhooks();
      const newWebhook = webhooks.find(webhook => webhook.id === auditEntry.target.id);
      
      if (newWebhook) {
        await newWebhook.delete('Koruma Sistemi: İzinsiz webhook oluşturma');
        logger.info(`İzinsiz oluşturulan webhook silindi.`);
      }
      
      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await channel.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz webhook oluşturma' });
        logger.info(`${executor.tag} kullanıcısı izinsiz webhook oluşturduğu için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const member = await channel.guild.members.fetch(executor.id);
        await member.kick('Koruma Sistemi: İzinsiz webhook oluşturma');
        logger.info(`${executor.tag} kullanıcısı izinsiz webhook oluşturduğu için atıldı.`);
      }
      
      // Log kanalına bilgi gönder
      if (settings.logChannelId) {
        const logChannel = channel.guild.channels.cache.get(settings.logChannelId);
        if (logChannel) {
          logChannel.send({
            embeds: [{
              title: '🔗 Webhook Koruma Sistemi',
              description: `**${executor.tag}** (${executor.id}) kullanıcısı **${channel.name}** kanalında izinsiz webhook oluşturdu ve yaptırım uygulandı.\n\nWebhook başarıyla silindi.`,
              color: 0xFF0000,
              timestamp: new Date()
            }]
          });
        }
      }
    } catch (error) {
      logger.error(`webhookUpdate event hatası: ${error}`);
    }
  }
};
