const { AuditLogEvent } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'guildBanAdd',
  once: false,
  async execute(client, ban) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: ban.guild.id });
      if (!settings || !settings.protectionEnabled) return;

      // Denetim kaydını kontrol et
      const auditLogs = await ban.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.MemberBanAdd
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, ban.guild.id, 'memberBan')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için ${ban.user.tag} kullanıcısını yasaklamasına izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${ban.user.tag} kullanıcısını yasaklamaya çalıştı!`);
      
      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await ban.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz kullanıcı yasaklama' });
        logger.info(`${executor.tag} kullanıcısı izinsiz ban attığı için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const member = await ban.guild.members.fetch(executor.id);
        await member.kick('Koruma Sistemi: İzinsiz kullanıcı yasaklama');
        logger.info(`${executor.tag} kullanıcısı izinsiz ban attığı için atıldı.`);
      }
      
      // Yasağı kaldır
      if (settings.banRecovery) {
        try {
          await ban.guild.members.unban(ban.user.id, 'Koruma Sistemi: İzinsiz yasaklama geri alındı');
          logger.info(`${ban.user.tag} kullanıcısının yasağı kaldırıldı.`);
          
          // Log kanalına bilgi gönder
          if (settings.logChannelId) {
            const logChannel = ban.guild.channels.cache.get(settings.logChannelId);
            if (logChannel) {
              logChannel.send({
                embeds: [{
                  title: '❌ Ban Koruma Sistemi',
                  description: `**${executor.tag}** (${executor.id}) kullanıcısı **${ban.user.tag}** (${ban.user.id}) kullanıcısını yasakladı ve yaptırım uygulandı.\n\nYasaklama başarıyla kaldırıldı.`,
                  color: 0xFF0000,
                  timestamp: new Date()
                }]
              });
            }
          }
        } catch (error) {
          logger.error(`Ban kaldırma hatası: ${error}`);
        }
      }
    } catch (error) {
      logger.error(`guildBanAdd event hatası: ${error}`);
    }
  }
};
