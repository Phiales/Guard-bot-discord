const { AuditLogEvent } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'guildMemberRemove',
  once: false,
  async execute(client, member) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: member.guild.id });
      if (!settings || !settings.protectionEnabled || !settings.protectionLevels.memberKick) return;

      // Denetim kaydını kontrol et
      const auditLogs = await member.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.MemberKick
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, member.guild.id, 'memberKick')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için ${member.user.tag} kullanıcısını atmasına izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${member.user.tag} kullanıcısını izinsiz attı!`);
      
      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await member.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz kullanıcı atma' });
        logger.info(`${executor.tag} kullanıcısı izinsiz kick attığı için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const executorMember = await member.guild.members.fetch(executor.id);
        await executorMember.kick('Koruma Sistemi: İzinsiz kullanıcı atma');
        logger.info(`${executor.tag} kullanıcısı izinsiz kick attığı için atıldı.`);
      }
      
      // Log kanalına bilgi gönder
      if (settings.logChannelId) {
        const logChannel = member.guild.channels.cache.get(settings.logChannelId);
        if (logChannel) {
          logChannel.send({
            embeds: [{
              title: '❌ Kick Koruma Sistemi',
              description: `**${executor.tag}** (${executor.id}) kullanıcısı **${member.user.tag}** (${member.user.id}) kullanıcısını izinsiz attı ve yaptırım uygulandı.`,
              color: 0xFF0000,
              timestamp: new Date()
            }]
          });
        }
      }
    } catch (error) {
      logger.error(`guildMemberRemove event hatası: ${error}`);
    }
  }
};
