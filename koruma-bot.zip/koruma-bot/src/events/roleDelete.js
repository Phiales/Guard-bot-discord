const { AuditLogEvent } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'roleDelete',
  once: false,
  async execute(client, role) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: role.guild.id });
      if (!settings || !settings.protectionEnabled || !settings.protectionLevels.roleDelete) return;

      // Denetim kaydını kontrol et
      const auditLogs = await role.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleDelete
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, role.guild.id, 'roleDelete')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için ${role.name} rolünü silmesine izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${role.name} rolünü silmeye çalıştı!`);
      
      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await role.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz rol silme' });
        logger.info(`${executor.tag} kullanıcısı izinsiz rol sildiği için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const member = await role.guild.members.fetch(executor.id);
        await member.kick('Koruma Sistemi: İzinsiz rol silme');
        logger.info(`${executor.tag} kullanıcısı izinsiz rol sildiği için atıldı.`);
      }
      
      // Rolü geri yükle
      if (settings.recoveryOptions.roleRecovery) {
        try {
          // Silinen rolün bilgilerini toplama
          const deletedRole = {
            name: role.name,
            color: role.color,
            hoist: role.hoist,
            permissions: role.permissions,
            mentionable: role.mentionable,
            position: role.rawPosition
          };
          
          // Yeni rol oluştur
          const newRole = await role.guild.roles.create({
            name: deletedRole.name,
            color: deletedRole.color,
            hoist: deletedRole.hoist,
            permissions: deletedRole.permissions,
            mentionable: deletedRole.mentionable,
            reason: 'Koruma Sistemi: Silinen rol geri yüklendi'
          });
          
          // Rolü eski pozisyonuna taşı (mümkünse)
          try {
            await newRole.setPosition(deletedRole.position);
          } catch (posError) {
            logger.error(`Rol pozisyonu ayarlama hatası: ${posError}`);
          }
          
          logger.info(`Silinen ${role.name} rolü başarıyla geri yüklendi.`);
          
          // Log kanalına bilgi gönder
          if (settings.logChannelId) {
            const logChannel = role.guild.channels.cache.get(settings.logChannelId);
            if (logChannel) {
              logChannel.send({
                embeds: [{
                  title: '❌ Rol Koruma Sistemi',
                  description: `**${executor.tag}** (${executor.id}) kullanıcısı **${role.name}** rolünü sildi ve yaptırım uygulandı.\n\nRol başarıyla geri yüklendi.`,
                  color: 0xFF0000,
                  timestamp: new Date()
                }]
              });
            }
          }
        } catch (error) {
          logger.error(`Rol geri yükleme hatası: ${error}`);
        }
      }
    } catch (error) {
      logger.error(`roleDelete event hatası: ${error}`);
    }
  }
};
