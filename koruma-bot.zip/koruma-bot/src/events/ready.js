const logger = require('../utils/logger');
const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    logger.info(`Bot hazır! ${client.user.tag} olarak giriş yapıldı.`);
    
    // Bot'un durumunu ayarla
    client.user.setPresence({
      activities: [{ 
        name: `Sunucunuzu 7/24 Koruyorum!`, 
        type: ActivityType.Watching 
      }],
      status: 'online'
    });
    
    // İstatistik bilgilerini logla
    logger.info(`${client.guilds.cache.size} sunucuda, toplam ${client.users.cache.size} kullanıcıya hizmet veriyor.`);
  }
};
