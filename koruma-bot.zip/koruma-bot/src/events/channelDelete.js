const { AuditLogEvent } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'channelDelete',
  once: false,
  async execute(client, channel) {
    // DM kanallarını yoksay
    if (!channel.guild) return;

    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: channel.guild.id });
      if (!settings || !settings.protectionEnabled) return;

      // Denetim kaydını kontrol et
      const auditLogs = await channel.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.ChannelDelete
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, channel.guild.id, 'channelDelete')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için ${channel.name} kanalını silmesine izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${channel.name} kanalını silmeye çalıştı!`);
      
      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await channel.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz kanal silme' });
        logger.info(`${executor.tag} kullanıcısı izinsiz kanal sildiği için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const member = await channel.guild.members.fetch(executor.id);
        await member.kick('Koruma Sistemi: İzinsiz kanal silme');
        logger.info(`${executor.tag} kullanıcısı izinsiz kanal sildiği için atıldı.`);
      }
      
      // Kanalı geri yükle
      if (settings.channelRecovery) {
        try {
          // Kanalı aynı kategoriye ve aynı izinlerle tekrar oluştur
          const newChannel = await channel.guild.channels.create({
            name: channel.name,
            type: channel.type,
            topic: channel.topic,
            nsfw: channel.nsfw,
            parent: channel.parent ? channel.parent.id : null,
            permissionOverwrites: channel.permissionOverwrites.cache.toJSON()
          });
          
          logger.info(`Silinen ${channel.name} kanalı başarıyla geri yüklendi.`);
          
          // Log kanalına bilgi gönder
          if (settings.logChannelId) {
            const logChannel = channel.guild.channels.cache.get(settings.logChannelId);
            if (logChannel) {
              logChannel.send({
                embeds: [{
                  title: '❌ Kanal Koruma Sistemi',
                  description: `**${executor.tag}** (${executor.id}) kullanıcısı **${channel.name}** kanalını sildi ve yaptırım uygulandı.\n\nKanal başarıyla geri yüklendi.`,
                  color: 0xFF0000,
                  timestamp: new Date()
                }]
              });
            }
          }
        } catch (error) {
          logger.error(`Kanal geri yükleme hatası: ${error}`);
        }
      }
    } catch (error) {
      logger.error(`channelDelete event hatası: ${error}`);
    }
  }
};
