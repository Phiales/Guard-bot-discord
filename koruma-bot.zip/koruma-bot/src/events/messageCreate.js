const { Collection } = require('discord.js');
const logger = require('../utils/logger');
const { handleSpamProtection } = require('../utils/antiSpam');

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(client, message) {
    // Önce Anti-Spam koruması kontrolü yap
    if (!message.author.bot && message.guild) {
      const isSpam = await handleSpamProtection(client, message);
      if (isSpam) return; // Spam tespit edildi, devam etme
    }
    
    // Bot mesajlarını kontrol et
    if (message.author.bot) return;
    
    // Komut değilse devam etme
    if (!message.content.startsWith(client.config.prefix)) return;

    // Komut ve argümanları ayır
    const args = message.content.slice(client.config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    // Komutu bul
    const command = client.commands.get(commandName) 
      || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

    if (!command) return;

    // DM kontrolü
    if (command.guildOnly && message.channel.type === 'dm') {
      return message.reply('❌ Bu komut özel mesajlarda kullanılamaz.');
    }

    // Yetki kontrolü
    if (command.permissions) {
      const authorPerms = message.channel.permissionsFor(message.author);
      if (!authorPerms || !authorPerms.has(command.permissions)) {
        return message.reply('❌ Bu komutu kullanmak için gerekli yetkiye sahip değilsiniz.');
      }
    }

    // Argüman kontrolü
    if (command.args && !args.length) {
      let reply = `❌ Bu komut için argüman belirtmelisiniz, ${message.author}!`;
      
      if (command.usage) {
        reply += `\nDoğru kullanım: \`${client.config.prefix}${command.name} ${command.usage}\``;
      }
      
      return message.reply(reply);
    }

    // Cooldown sistemi
    const { cooldowns } = client;

    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Collection());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 3) * 1000;

    if (timestamps.has(message.author.id)) {
      const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

      if (now < expirationTime) {
        const timeLeft = (expirationTime - now) / 1000;
        return message.reply(
          `❌ Lütfen \`${command.name}\` komutunu kullanmadan önce ${timeLeft.toFixed(1)} saniye bekleyin.`
        );
      }
    }

    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

    // Komutu çalıştır
    try {
      await command.execute(client, message, args);
      logger.info(`${message.author.tag} tarafından ${command.name} komutu kullanıldı`);
    } catch (error) {
      logger.error(`Komut hatası: ${command.name} - ${error}`);
      message.reply('❌ Bu komutu çalıştırırken bir hata oluştu!');
    }
  }
};
