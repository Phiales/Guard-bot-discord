const logger = require('../utils/logger');
const { handleRaidProtection } = require('../utils/antiRaid');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'guildMemberAdd',
  once: false,
  async execute(client, member) {
    try {
      // Anti-Raid koruması
      const raidDetected = await handleRaidProtection(client, member);
      
      // Raid tespit edilmişse, başka işlem yapma
      if (raidDetected) return;
      
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: member.guild.id });
      if (!settings) return;
      
      // Bot kontrolü (Güvenli değilse)
      if (member.user.bot) {
        // Bot koruması aktif mi?
        if (settings.protectionLevels.botAdd) {
          // Bot ekleyen kullanıcıyı bul
          const auditLogs = await member.guild.fetchAuditLogs({
            limit: 1,
            type: 28 // BOT_ADD
          });
          
          const auditEntry = auditLogs.entries.first();
          
          // Yetkisi olmayan kullanıcı bot eklediyse
          if (auditEntry && Date.now() - auditEntry.createdTimestamp < 10000) {
            const executor = auditEntry.executor;
            
            const { checkPermission } = require('../utils/permissionCheck');
            if (!await checkPermission(executor.id, member.guild.id, 'botAdd')) {
              logger.warn(`Bot Koruma: ${executor.tag} kullanıcısı ${member.user.tag} botunu izinsiz ekledi!`);
              
              // Botu at
              await member.kick('Koruma Sistemi: İzinsiz bot ekleme');
              
              // Kullanıcıyı cezalandır
              if (settings.punishmentType === 'ban') {
                await member.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz bot ekleme' });
                logger.info(`${executor.tag} kullanıcısı izinsiz bot eklediği için yasaklandı.`);
              } else if (settings.punishmentType === 'kick') {
                const executorMember = await member.guild.members.fetch(executor.id);
                await executorMember.kick('Koruma Sistemi: İzinsiz bot ekleme');
                logger.info(`${executor.tag} kullanıcısı izinsiz bot eklediği için atıldı.`);
              }
              
              // Log kanalına bilgi gönder
              if (settings.logChannelId) {
                const logChannel = member.guild.channels.cache.get(settings.logChannelId);
                if (logChannel) {
                  logChannel.send({
                    embeds: [{
                      title: '🤖 Bot Koruma Sistemi',
                      description: `**${executor.tag}** (${executor.id}) kullanıcısı **${member.user.tag}** (${member.user.id}) botunu izinsiz ekledi!\n\nBot sunucudan çıkarıldı ve gerekli yaptırım uygulandı.`,
                      color: 0xFF0000,
                      timestamp: new Date()
                    }]
                  });
                }
              }
              
              return;
            }
          }
        }
      }
      
      // Anti-Spam koruma etkinleştirilmişse ve hoşgeldin mesajı ayarlanmışsa
      if (settings.welcomeEnabled && settings.welcomeChannelId && settings.welcomeMessage) {
        const welcomeChannel = member.guild.channels.cache.get(settings.welcomeChannelId);
        if (welcomeChannel) {
          // Değişkenleri değiştir
          const welcomeMessage = settings.welcomeMessage
            .replace('{user}', `<@${member.id}>`)
            .replace('{username}', member.user.username)
            .replace('{server}', member.guild.name)
            .replace('{memberCount}', member.guild.memberCount);
          
          welcomeChannel.send(welcomeMessage);
        }
      }
      
      // Otomatik rol verme
      if (settings.autoRoleEnabled && settings.autoRoleId) {
        try {
          // Botlara farklı rol verebilmek için
          if (member.user.bot && settings.botRoleId) {
            await member.roles.add(settings.botRoleId, 'Otomatik Bot Rolü');
          } else {
            await member.roles.add(settings.autoRoleId, 'Otomatik Üye Rolü');
          }
        } catch (error) {
          logger.error(`Otomatik rol verme hatası: ${error}`);
        }
      }
    } catch (error) {
      logger.error(`guildMemberAdd event hatası: ${error}`);
    }
  }
};
