const { AuditLogEvent, PermissionsBitField } = require('discord.js');
const logger = require('../utils/logger');
const { checkPermission } = require('../utils/permissionCheck');
const ServerSettings = require('../models/serverSettings');

module.exports = {
  name: 'roleUpdate',
  once: false,
  async execute(client, oldRole, newRole) {
    try {
      // Sunucu ayarlarını getir
      const settings = await ServerSettings.findOne({ guildId: newRole.guild.id });
      if (!settings || !settings.protectionEnabled) return;

      // Denetim kaydını kontrol et
      const auditLogs = await newRole.guild.fetchAuditLogs({
        limit: 1,
        type: AuditLogEvent.RoleUpdate
      });
      
      const auditEntry = auditLogs.entries.first();
      
      // Audit log bulunamadıysa veya çok eskiyse işlem yapma
      if (!auditEntry || Date.now() - auditEntry.createdTimestamp > 5000) return;
      
      const executor = auditEntry.executor;
      
      // Bot kendi kendine işlem yapıyorsa yoksay
      if (executor.id === client.user.id) return;
      
      // Tehlikeli yetki değişikliği kontrolü
      const oldPermissions = oldRole.permissions;
      const newPermissions = newRole.permissions;
      
      const criticalPermissions = [
        PermissionsBitField.Flags.Administrator,
        PermissionsBitField.Flags.BanMembers,
        PermissionsBitField.Flags.KickMembers,
        PermissionsBitField.Flags.ManageChannels,
        PermissionsBitField.Flags.ManageGuild,
        PermissionsBitField.Flags.ManageRoles,
        PermissionsBitField.Flags.ManageWebhooks
      ];
      
      // Yeni eklenen tehlikeli yetkiler var mı kontrol et
      const addedCriticalPermissions = criticalPermissions.filter(permission => 
        !oldPermissions.has(permission) && newPermissions.has(permission)
      );
      
      // Tehlikeli yetki eklenmemiş ise ve ya@-everyone rolü değilse işlem yapma
      if (addedCriticalPermissions.length === 0 && newRole.id !== newRole.guild.id) return;
      
      // Güvenli kullanıcı kontrolü
      if (await checkPermission(executor.id, newRole.guild.id, 'roleUpdate')) {
        logger.info(`${executor.tag} kullanıcısı güvenli listede olduğu için ${newRole.name} rolünü güncellemesine izin verildi.`);
        return;
      }

      // İhlal tespit edildi, işlem yap
      logger.warn(`Koruma: ${executor.tag} kullanıcısı ${newRole.name} rolüne tehlikeli yetkiler eklemeye çalıştı!`);
      
      // Rol değişikliklerini geri al
      try {
        await newRole.setPermissions(oldPermissions);
        if (oldRole.name !== newRole.name) await newRole.setName(oldRole.name);
        if (oldRole.color !== newRole.color) await newRole.setColor(oldRole.color);
        if (oldRole.hoist !== newRole.hoist) await newRole.setHoist(oldRole.hoist);
        if (oldRole.mentionable !== newRole.mentionable) await newRole.setMentionable(oldRole.mentionable);
        
        logger.info(`${newRole.name} rolündeki değişiklikler geri alındı.`);
      } catch (error) {
        logger.error(`Rol değişiklikleri geri alma hatası: ${error}`);
      }

      // Kullanıcıyı cezalandır (ayarlara göre)
      if (settings.punishmentType === 'ban') {
        await newRole.guild.members.ban(executor.id, { reason: 'Koruma Sistemi: İzinsiz rol yetkisi yükseltme' });
        logger.info(`${executor.tag} kullanıcısı izinsiz rol yetkilerini değiştirdiği için yasaklandı.`);
      } else if (settings.punishmentType === 'kick') {
        const member = await newRole.guild.members.fetch(executor.id);
        await member.kick('Koruma Sistemi: İzinsiz rol yetkisi yükseltme');
        logger.info(`${executor.tag} kullanıcısı izinsiz rol yetkilerini değiştirdiği için atıldı.`);
      }
      
      // Log kanalına bilgi gönder
      if (settings.logChannelId) {
        const logChannel = newRole.guild.channels.cache.get(settings.logChannelId);
        if (logChannel) {
          logChannel.send({
            embeds: [{
              title: '❌ Rol Koruma Sistemi',
              description: `**${executor.tag}** (${executor.id}) kullanıcısı **${newRole.name}** rolüne tehlikeli yetkiler eklemeye çalıştı ve yaptırım uygulandı.\n\nDeğişiklikler başarıyla geri alındı.`,
              color: 0xFF0000,
              timestamp: new Date()
            }]
          });
        }
      }
    } catch (error) {
      logger.error(`roleUpdate event hatası: ${error}`);
    }
  }
};
