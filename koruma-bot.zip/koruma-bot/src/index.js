const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { readdirSync } = require('fs');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const logger = require('./utils/logger');

// Çevre değişkenlerini yükle
dotenv.config();

// Discord client'ını tüm ihtiyaç duyulan intent'ler ile oluştur
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.GuildMember,
    Partials.Reaction,
    Partials.User,
    Partials.ThreadMember
  ],
  allowedMentions: {
    parse: ['users', 'roles'],
    repliedUser: true
  }
});

// Global değişkenler
client.commands = new Collection();
client.cooldowns = new Collection();
client.config = {
  prefix: process.env.PREFIX || '!',
  token: process.env.TOKEN,
  mongoUri: process.env.MONGO_URI
};

// MongoDB bağlantısı
mongoose.connect(client.config.mongoUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  logger.info('MongoDB bağlantısı başarıyla kuruldu.');
}).catch((err) => {
  logger.error(`MongoDB bağlantı hatası: ${err}`);
});

// Komutları yükle
const commandFolders = readdirSync(path.join(__dirname, 'commands'));

for (const folder of commandFolders) {
  const commandFiles = readdirSync(path.join(__dirname, 'commands', folder)).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(__dirname, 'commands', folder, file));
    client.commands.set(command.name, command);
    logger.info(`Komut yüklendi: ${command.name}`);
  }
}

// Event'leri yükle
const eventFiles = readdirSync(path.join(__dirname, 'events')).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const event = require(path.join(__dirname, 'events', file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(client, ...args));
  } else {
    client.on(event.name, (...args) => event.execute(client, ...args));
  }
  logger.info(`Event yüklendi: ${event.name}`);
}

// Hata yakalayıcılar
process.on('unhandledRejection', (reason, promise) => {
  logger.error(`İşlenmeyen Rejection: ${reason}`);
  // console.log(reason);
});

process.on('uncaughtException', (err) => {
  logger.error(`Yakalanmayan Hata: ${err}`);
  // console.log(err);
});

// Bot'u başlat
client.login(client.config.token)
  .then(() => {
    logger.info(`Bot başarıyla giriş yaptı: ${client.user.tag}`);
  })
  .catch((err) => {
    logger.error(`Bot giriş hatası: ${err}`);
  });
