# 🛡️ Discord Koruma Botu

Bu bot, Discord sunucularınızı çeşitli tehdit ve saldırılara karşı koruyan, Türkçe arayüze sahip gelişmiş bir güvenlik botudur.

## ✨ Özellikler

- **Tam Koruma**: Sunucunuzu izinsiz kanal/rol silme, tehlikeli yetki değişiklikleri, izinsiz ban/kick işlemlerine karşı korur.
- **Anti-Raid Sistemi**: Kısa sürede çok sayıda kullanıcının katılımını algılayarak sunucunuzu ani baskınlara karşı korur.
- **Güvenli Liste**: Belirlediğiniz kullanıcı ve roller için koruma sisteminde istisna oluşturabilirsiniz.
- **Özelleştirilebilir Cezalar**: İhlal durumunda ban, kick veya sadece izleme seçeneklerinden birini seçebilirsiniz.
- **Detaylı Loglar**: Tüm koruma olayları belirlediğiniz log kanalına detaylı olarak raporlanır.
- **Türkçe Arayüz**: Tüm komutlar ve bildirimler Türkçe olarak sunulur.

## 📥 Kurulum

1. Bu depoyu bilgisayarınıza klonlayın:
   ```
   git clone https://github.com/kullaniciadi/koruma-bot.git
   ```

2. Proje dizinine gidin:
   ```
   cd koruma-bot
   ```

3. Gerekli bağımlılıkları yükleyin:
   ```
   npm install
   ```

4. `.env` dosyasını düzenleyin:
   ```
   TOKEN=BOT_TOKENINIZI_BURAYA_GIRIN
   MONGO_URI=MONGODB_BAGLANTI_ADRESINIZI_BURAYA_GIRIN
   PREFIX=!
   ```

5. Botu başlatın:
   ```
   npm start
   ```

## ⚙️ Temel Ayarlar

Bot'u sunucunuza ekledikten sonra, aşağıdaki komutlarla temel ayarları yapabilirsiniz:

- `!koruma aç` - Koruma sistemini aktifleştirir
- `!koruma kapat` - Koruma sistemini devre dışı bırakır
- `!logkanal #kanal` - Log mesajlarının gönderileceği kanalı ayarlar
- `!ceza ban/kick/none` - İhlal durumunda uygulanacak cezayı belirler
- `!raid aç` - Anti-raid korumasını aktifleştirir
- `!raid ayarla 10 5` - 5 saniye içinde 10 kişi katılırsa raid korumasını tetikler
- `!durum` - Sunucunun koruma durumunu gösterir

## 🔐 Güvenli Liste Yönetimi

Koruma sisteminden etkilenmemesini istediğiniz kullanıcı ve rolleri güvenli listeye ekleyebilirsiniz:

- `!guvenli ekle @kullanıcı` - Bir kullanıcıyı güvenli listeye ekler
- `!guvenli ekle @rol` - Bir rolü güvenli listeye ekler
- `!guvenli çıkar @kullanıcı` - Bir kullanıcıyı güvenli listeden çıkarır
- `!guvenli liste` - Güvenli listedeki kullanıcı ve rolleri gösterir

## 🚨 Koruma Özellikleri

Bu bot aşağıdaki durumları tespit eder ve ayarlarınıza göre önlem alır:

1. **Kanal Silme Koruması**: İzinsiz kanal silme işlemlerini engeller ve kanalı geri getirir.
2. **Rol Silme Koruması**: İzinsiz rol silme işlemlerini engeller ve rolü geri getirir.
3. **Yetki Yükseltme Koruması**: Tehlikeli yetki değişikliklerini algılar ve geri alır.
4. **Ban/Kick Koruması**: İzinsiz ban ve kick işlemlerini tespit eder, gerekirse geri alır.
5. **Bot Koruması**: Yetkisiz kişilerin sunucuya bot eklemesini engeller.
6. **Anti-Raid Koruması**: Kısa sürede çok sayıda kullanıcı katılımını algılar ve önlem alır.

## 🔍 Hata Ayıklama

Bot çalışmazsa veya hata alırsanız aşağıdaki adımları deneyin:

1. `.env` dosyasındaki token ve MongoDB URI bilgilerinin doğru olduğundan emin olun.
2. Bot hesabına gerekli izinlerin verildiğinden emin olun.
3. Log dosyalarını kontrol edin: `logs/error.log` ve `logs/combined.log`.

## 📝 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Daha fazla bilgi için `LICENSE` dosyasına bakın.

## 🤝 Katkıda Bulunma

1. Bu depoyu fork edin
2. Yeni bir özellik branch'ı oluşturun (`git checkout -b yeni-ozellik`)
3. Değişikliklerinizi commit edin (`git commit -am 'Yeni özellik: X'`)
4. Branch'inizi push edin (`git push origin yeni-ozellik`)
5. Bir Pull Request oluşturun

---

⭐ Bu projeyi beğendiyseniz yıldız vermeyi unutmayın!
